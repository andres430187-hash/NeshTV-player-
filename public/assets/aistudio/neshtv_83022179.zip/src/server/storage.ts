import fs from 'fs';
import path from 'path';

export interface UserAccount {
  id: string;
  username: string;
  password: string;
  expiryDate: string; // YYYY-MM-DD
  status: 'active' | 'blocked';
  notes?: string;
  blockedChannels?: string[]; // IDs of channels blocked for this user
  createdAt: string;
}

export interface ChannelItem {
  id: string;
  number: number;
  name: string;
  category: string;
  logo: string;
  url: string;
  epgNow: {
    title: string;
    startTime: string;
    endTime: string;
    description: string;
  };
  epgNext: {
    title: string;
    startTime: string;
    endTime: string;
    description: string;
  };
  resolution?: string;
  isBlocked?: boolean;
}

export interface VodItem {
  id: string;
  title: string;
  category: string;
  type: 'movie' | 'series';
  year: number;
  rating: string;
  poster: string;
  backdrop?: string;
  synopsis: string;
  duration?: string;
  seasons?: number;
  episodesCount?: number;
  url: string;
  isBlocked?: boolean;
}

export interface IPTVPlaylist {
  id: string;
  name: string;
  type: 'm3u' | 'xtream';
  url: string;
  username?: string;
  password?: string;
  lastSynced: string;
  channelCount: number;
  active: boolean;
}

export interface FloatingMessage {
  id: string;
  text: string;
  sender: string;
  targetUserId?: string; // 'all' or specific user id
  active: boolean;
  type: 'info' | 'warning' | 'urgent';
  createdAt: string;
}

export interface PlayerSettings {
  decoder: 'hardware' | 'software';
  bufferSize: number; // e.g. 20
  enableOpenSLES: boolean;
  enableOpenGL: boolean;
  playbackFormat: 'default' | 'mpegts' | 'hls';
  categoryEngines: {
    live: string;
    movies: string;
    series: string;
    catchup: string;
    recording: string;
    liveWithGuide: string;
  };
}

export interface AppDatabase {
  users: UserAccount[];
  contactNote: string;
  floatingMessage: FloatingMessage;
  playlists: IPTVPlaylist[];
  channels: ChannelItem[];
  vod: VodItem[];
  playerSettings: PlayerSettings;
  activePlaylistId?: string;
  activeXtreamSource?: {
    id: string;
    name: string;
    serverUrl: string;
    username?: string;
    status: string;
    expDate?: string;
    totalChannels: number;
    totalVod: number;
    lastSynced: string;
  } | null;
}

const DATA_FILE = path.resolve(process.cwd(), 'neshtv-db.json');

const INITIAL_DB: AppDatabase = {
  users: [
    {
      id: 'usr_admin',
      username: 'admin',
      password: 'Admin2026',
      expiryDate: '2035-12-31',
      status: 'active',
      notes: 'Super Administrador / Propietario NeshTV',
      blockedChannels: [],
      createdAt: '2026-01-01T00:00:00Z',
    },
    {
      id: 'usr_1',
      username: 'demo',
      password: 'demo123',
      expiryDate: '2027-12-31',
      status: 'active',
      notes: 'Cuenta de prueba demostrativa',
      blockedChannels: [],
      createdAt: '2026-01-10T10:00:00Z',
    },
    {
      id: 'usr_2',
      username: 'cliente1',
      password: '123456',
      expiryDate: '2027-08-15',
      status: 'active',
      notes: 'Plan Familiar 3 pantallas',
      blockedChannels: [],
      createdAt: '2026-02-01T12:00:00Z',
    },
    {
      id: 'usr_3',
      username: 'suspendido',
      password: 'test123',
      expiryDate: '2026-01-01',
      status: 'blocked',
      notes: 'Suspendido por falta de pago',
      blockedChannels: [],
      createdAt: '2025-11-20T08:00:00Z',
    },
  ],
  contactNote: 'Para solicitar nuevas cuentas, renovaciones o soporte técnico, contáctanos vía WhatsApp al +52 55 1234 5678 o visita neshtv.com',
  floatingMessage: {
    id: 'msg_1',
    text: 'Aviso NeshTV: Mantén tu suscripción al día para no perder tus canales favoritos. Próxima actualización de cartelera disponible.',
    sender: 'Administrador NeshTV',
    targetUserId: 'all',
    active: true,
    type: 'info',
    createdAt: new Date().toISOString(),
  },
  playlists: [
    {
      id: 'pl_1',
      name: 'NeshTV Servidor Primario (Ultra HD)',
      type: 'm3u',
      url: 'https://iptv.neshtv.net/api/v2/stream.m3u',
      username: 'nesh_main',
      password: '••••••••',
      lastSynced: '2026-10-20T05:00:00Z',
      channelCount: 12,
      active: true,
    },
    {
      id: 'pl_2',
      name: 'Xtream Codes Backup Backup',
      type: 'xtream',
      url: 'http://xtream.neshtv-cdn.com:8080',
      username: 'admin_relay',
      password: '••••••••',
      lastSynced: '2026-10-18T14:30:00Z',
      channelCount: 250,
      active: true,
    },
  ],
  channels: [
    {
      id: 'ch_1',
      number: 101,
      name: 'ESPN Deportes HD',
      category: 'Deportes',
      logo: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=120&auto=format&fit=crop&q=80',
      url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
      resolution: '1080p 60fps',
      isBlocked: false,
      epgNow: {
        title: 'Fútbol Internacional: Champions League - Previa',
        startTime: '10:00',
        endTime: '12:30',
        description: 'Análisis detallado de la jornada europea con los mejores panelistas deportivos.',
      },
      epgNext: {
        title: 'SportsCenter Primera Edición',
        startTime: '12:30',
        endTime: '14:00',
        description: 'Resumen completo de las noticias deportivas más relevantes a nivel mundial.',
      },
    },
    {
      id: 'ch_2',
      number: 102,
      name: 'Fox Sports 1 UHD',
      category: 'Deportes',
      logo: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=120&auto=format&fit=crop&q=80',
      url: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
      resolution: '4K Ultra HD',
      isBlocked: false,
      epgNow: {
        title: 'Formula 1: Gran Premio de las Américas - Prácticas',
        startTime: '11:00',
        endTime: '13:00',
        description: 'Transmisión exclusiva desde el circuito principal con telemetría en vivo.',
      },
      epgNext: {
        title: 'Central Fox Noticias',
        startTime: '13:00',
        endTime: '14:30',
        description: 'Debate en caliente sobre la actualidad de los clubes y atletas.',
      },
    },
    {
      id: 'ch_3',
      number: 201,
      name: 'HBO Max Cinema HD',
      category: 'Cine & Series',
      logo: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=120&auto=format&fit=crop&q=80',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      resolution: '1080p Surround 5.1',
      isBlocked: false,
      epgNow: {
        title: 'Dune: Parte Dos (Estreno Exclusivo)',
        startTime: '09:45',
        endTime: '12:45',
        description: 'Paul Atreides se une a Chani y a los Fremen mientras busca venganza contra los conspiradores.',
      },
      epgNext: {
        title: 'Oppenheimer',
        startTime: '12:45',
        endTime: '15:45',
        description: 'La historia del científico estadounidense J. Robert Oppenheimer y su rol en el Proyecto Manhattan.',
      },
    },
    {
      id: 'ch_4',
      number: 202,
      name: 'Warner TV Latino',
      category: 'Cine & Series',
      logo: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=120&auto=format&fit=crop&q=80',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
      resolution: '1080p',
      isBlocked: false,
      epgNow: {
        title: 'The Big Bang Theory - Temporada 10 Maratón',
        startTime: '11:30',
        endTime: '13:00',
        description: 'Episodios consecutivos de las aventuras cómicas de Sheldon, Leonard y Penny.',
      },
      epgNext: {
        title: 'Arrow - Flecha Verde',
        startTime: '13:00',
        endTime: '14:00',
        description: 'Oliver Queen lucha por la justicia en Starling City.',
      },
    },
    {
      id: 'ch_5',
      number: 301,
      name: 'CNN en Español',
      category: 'Noticias',
      logo: 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=120&auto=format&fit=crop&q=80',
      url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
      resolution: '1080p',
      isBlocked: false,
      epgNow: {
        title: 'Conclusiones con Fernando del Rincón',
        startTime: '11:00',
        endTime: '12:00',
        description: 'Análisis político exhaustivo de las noticias clave en América Latina.',
      },
      epgNext: {
        title: 'Directo USA',
        startTime: '12:00',
        endTime: '13:00',
        description: 'Información y desarrollo de acontecimientos internacionales.',
      },
    },
    {
      id: 'ch_6',
      number: 302,
      name: 'BBC News World',
      category: 'Noticias',
      logo: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=120&auto=format&fit=crop&q=80',
      url: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
      resolution: '1080p',
      isBlocked: false,
      epgNow: {
        title: 'Global News Hour Live',
        startTime: '11:30',
        endTime: '12:30',
        description: 'The latest updates from correspondents around the globe.',
      },
      epgNext: {
        title: 'BBC World Business Report',
        startTime: '12:30',
        endTime: '13:00',
        description: 'Financial markets and technology developments.',
      },
    },
    {
      id: 'ch_7',
      number: 401,
      name: 'National Geographic Wild',
      category: 'Documentales',
      logo: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=120&auto=format&fit=crop&q=80',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      resolution: '4K Ultra HD',
      isBlocked: false,
      epgNow: {
        title: 'Depredadores de la Sabana Africana',
        startTime: '11:00',
        endTime: '12:30',
        description: 'El seguimiento íntimo a las manadas de leones y guepardos en el Serengueti.',
      },
      epgNext: {
        title: 'Secretos del Océano Profundo',
        startTime: '12:30',
        endTime: '14:00',
        description: 'Expedición a las fosas marinas descubriendo criaturas bioluminiscentes.',
      },
    },
    {
      id: 'ch_8',
      number: 402,
      name: 'Discovery Channel HD',
      category: 'Documentales',
      logo: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=120&auto=format&fit=crop&q=80',
      url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
      resolution: '1080p',
      isBlocked: false,
      epgNow: {
        title: 'Mega Construcciones: Rascacielos del Futuro',
        startTime: '10:30',
        endTime: '12:00',
        description: 'Ingeniería moderna al límite en proyectos monumentales de Asia y Europa.',
      },
      epgNext: {
        title: 'Cazadores de Mitos',
        startTime: '12:00',
        endTime: '13:00',
        description: 'Experimentos científicos poniendo a prueba leyendas urbanas.',
      },
    },
    {
      id: 'ch_9',
      number: 501,
      name: 'Cartoon Network Plus',
      category: 'Infantil',
      logo: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=120&auto=format&fit=crop&q=80',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      resolution: '1080p',
      isBlocked: false,
      epgNow: {
        title: 'El Increíble Mundo de Gumball',
        startTime: '11:00',
        endTime: '12:00',
        description: 'Locuras divertidas de Gumball y Darwin Watterson.',
      },
      epgNext: {
        title: 'Hora de Aventura con Finn y Jake',
        startTime: '12:00',
        endTime: '13:00',
        description: 'Viajes heroicos en la mágica Tierra de Ooo.',
      },
    },
    {
      id: 'ch_10',
      number: 601,
      name: 'MTV Live Hits & Beats',
      category: 'Música',
      logo: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=120&auto=format&fit=crop&q=80',
      url: 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
      resolution: '1080p Audio Hi-Fi',
      isBlocked: false,
      epgNow: {
        title: 'Top 50 Hits Urban & Pop 2026',
        startTime: '10:00',
        endTime: '12:00',
        description: 'Los vídeos musicales más reproducidos a nivel global.',
      },
      epgNext: {
        title: 'MTV World Stage Live Concerts',
        startTime: '12:00',
        endTime: '13:30',
        description: 'Conciertos multitudinarios en vivo de las principales estrellas.',
      },
    },
  ],
  vod: [
    {
      id: 'vod_1',
      title: 'Dune: Part Two',
      category: 'Ciencia Ficción',
      type: 'movie',
      year: 2024,
      rating: '8.6',
      poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&auto=format&fit=crop&q=80',
      synopsis: 'Paul Atreides se une a Chani y a los Fremen mientras busca venganza contra los conspiradores que destruyeron a su familia.',
      duration: '2h 46m',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    },
    {
      id: 'vod_2',
      title: 'Oppenheimer',
      category: 'Drama Histórico',
      type: 'movie',
      year: 2023,
      rating: '8.9',
      poster: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&auto=format&fit=crop&q=80',
      synopsis: 'La historia del físico estadounidense J. Robert Oppenheimer, al frente del Laboratorio de Los Álamos.',
      duration: '3h 00m',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    },
    {
      id: 'vod_3',
      title: 'Interstellar 4K',
      category: 'Aventura Espacial',
      type: 'movie',
      year: 2014,
      rating: '8.7',
      poster: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&auto=format&fit=crop&q=80',
      synopsis: 'Un equipo de exploradores viaja a través de un agujero de gusano en el espacio en un intento por asegurar la supervivencia de la humanidad.',
      duration: '2h 49m',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    },
    {
      id: 'vod_4',
      title: 'The Last of Us',
      category: 'Drama / Supervivencia',
      type: 'series',
      year: 2023,
      rating: '8.8',
      poster: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&auto=format&fit=crop&q=80',
      synopsis: 'Joel y Ellie son emparejados a través del peligroso paisaje postapocalíptico de los Estados Unidos.',
      seasons: 2,
      episodesCount: 16,
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    },
    {
      id: 'vod_5',
      title: 'Stranger Things',
      category: 'Fantasía / Misterio',
      type: 'series',
      year: 2024,
      rating: '8.7',
      poster: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400&auto=format&fit=crop&q=80',
      synopsis: 'En un pequeño pueblo donde todos se conocen, un extraño incidente desata una cadena de eventos con fuerzas sobrenaturales.',
      seasons: 5,
      episodesCount: 42,
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    },
  ],
  playerSettings: {
    decoder: 'hardware',
    bufferSize: 20,
    enableOpenSLES: true,
    enableOpenGL: true,
    playbackFormat: 'hls',
    categoryEngines: {
      live: 'ExoPlayer Built-in (Recomendado)',
      movies: 'VLC Hardware Engine',
      series: 'VLC Hardware Engine',
      catchup: 'IjkPlayer Fast-Seek',
      recording: 'Standard MediaCodec',
      liveWithGuide: 'ExoPlayer Low-Latency',
    },
  },
};

export class StorageService {
  private static instance: StorageService;
  private db: AppDatabase;

  private constructor() {
    this.db = this.loadData();
  }

  public static getInstance(): StorageService {
    if (!StorageService.instance) {
      StorageService.instance = new StorageService();
    }
    return StorageService.instance;
  }

  private loadData(): AppDatabase {
    let loaded: AppDatabase;
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        loaded = JSON.parse(raw);
      } else {
        loaded = JSON.parse(JSON.stringify(INITIAL_DB));
      }
    } catch (e) {
      console.warn('Error reading db file, using initial data:', e);
      loaded = JSON.parse(JSON.stringify(INITIAL_DB));
    }

    // Ensure super admin always exists and has the correct password Admin2026
    const adminIdx = loaded.users.findIndex(u => u.username.toLowerCase() === 'admin');
    if (adminIdx === -1) {
      loaded.users.unshift({
        id: 'usr_admin',
        username: 'admin',
        password: 'Admin2026',
        expiryDate: '2035-12-31',
        status: 'active',
        notes: 'Super Administrador / Propietario NeshTV',
        blockedChannels: [],
        createdAt: '2026-01-01T00:00:00Z',
      });
    } else {
      loaded.users[adminIdx].password = 'Admin2026';
      loaded.users[adminIdx].status = 'active';
      loaded.users[adminIdx].expiryDate = '2035-12-31';
    }

    this.saveData(loaded);
    return loaded;
  }

  private saveData(data: AppDatabase): void {
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error saving db file:', e);
    }
  }

  public getDb(): AppDatabase {
    return this.db;
  }

  public getPublicInfo() {
    return {
      contactNote: this.db.contactNote,
    };
  }

  public authenticateClient(username: string, password: string): { success: boolean; user?: UserAccount; suspended?: boolean; message?: string } {
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    // Special handling for master admin
    if (cleanUser === 'admin') {
      if (cleanPass === 'Admin2026' || cleanPass === 'admin2026') {
        const adminUser = this.db.users.find(u => u.username.toLowerCase() === 'admin') || {
          id: 'usr_admin',
          username: 'admin',
          password: 'Admin2026',
          expiryDate: '2035-12-31',
          status: 'active',
          notes: 'Super Administrador / Propietario NeshTV',
          blockedChannels: [],
          createdAt: '2026-01-01T00:00:00Z',
        };
        return { success: true, user: adminUser };
      } else {
        return { success: false, message: 'Contraseña de administrador incorrecta (Admin2026)' };
      }
    }

    const user = this.db.users.find(u => u.username.toLowerCase() === cleanUser);
    if (!user) {
      return { success: false, message: 'Usuario no encontrado' };
    }
    if (user.password !== cleanPass) {
      return { success: false, message: 'Contraseña incorrecta' };
    }
    if (user.status === 'blocked') {
      return { success: false, suspended: true, message: 'Cuenta suspendida por falta de pago. Contacte al administrador.' };
    }
    // Check expiry
    const now = new Date();
    const expiry = new Date(user.expiryDate);
    if (expiry < now) {
      return { success: false, suspended: true, message: `Tu suscripción venció el ${user.expiryDate}. Renueva con el administrador.` };
    }
    return { success: true, user };
  }

  public authenticateAdmin(username: string, password: string): boolean {
    const u = username.trim().toLowerCase();
    const p = password.trim();
    return u === 'admin' && (p === 'Admin2026' || p === 'admin2026');
  }

  public addUser(user: Omit<UserAccount, 'id' | 'createdAt'>): UserAccount {
    const newUser: UserAccount = {
      ...user,
      id: `usr_${Date.now()}`,
      createdAt: new Date().toISOString(),
      blockedChannels: user.blockedChannels || [],
    };
    this.db.users.push(newUser);
    this.saveData(this.db);
    return newUser;
  }

  public updateUser(id: string, updates: Partial<UserAccount>): UserAccount | null {
    const index = this.db.users.findIndex(u => u.id === id);
    if (index === -1) return null;
    this.db.users[index] = { ...this.db.users[index], ...updates };
    this.saveData(this.db);
    return this.db.users[index];
  }

  public deleteUser(id: string): boolean {
    const target = this.db.users.find(u => u.id === id);
    if (target && target.username.toLowerCase() === 'admin') return false;

    const initialLen = this.db.users.length;
    this.db.users = this.db.users.filter(u => u.id !== id);
    if (this.db.floatingMessage.targetUserId === id) {
      this.db.floatingMessage.targetUserId = 'all';
    }
    this.saveData(this.db);
    return true;
  }

  public deleteUnpaidUsers(): number {
    const todayStr = new Date().toISOString().split('T')[0];
    const initialLen = this.db.users.length;
    this.db.users = this.db.users.filter(u => {
      if (u.username.toLowerCase() === 'admin') return true;
      const isBlocked = u.status === 'blocked';
      const isExpired = u.expiryDate < todayStr;
      return !isBlocked && !isExpired;
    });
    const deletedCount = initialLen - this.db.users.length;
    this.saveData(this.db);
    return deletedCount;
  }

  public updateContactNote(note: string): string {
    this.db.contactNote = note;
    this.saveData(this.db);
    return this.db.contactNote;
  }

  public updateFloatingMessage(msg: Partial<FloatingMessage>): FloatingMessage {
    this.db.floatingMessage = {
      ...this.db.floatingMessage,
      ...msg,
      createdAt: new Date().toISOString(),
    };
    this.saveData(this.db);
    return this.db.floatingMessage;
  }

  public addPlaylist(playlist: Omit<IPTVPlaylist, 'id' | 'lastSynced'>): IPTVPlaylist {
    const newPl: IPTVPlaylist = {
      ...playlist,
      id: `pl_${Date.now()}`,
      lastSynced: new Date().toISOString(),
    };
    this.db.playlists.push(newPl);
    this.saveData(this.db);
    return newPl;
  }

  public updatePlaylist(id: string, updates: Partial<IPTVPlaylist>): IPTVPlaylist | null {
    const idx = this.db.playlists.findIndex(p => p.id === id);
    if (idx === -1) return null;
    this.db.playlists[idx] = { ...this.db.playlists[idx], ...updates };
    this.saveData(this.db);
    return this.db.playlists[idx];
  }

  public deletePlaylist(id: string): boolean {
    const len = this.db.playlists.length;
    this.db.playlists = this.db.playlists.filter(p => p.id !== id);
    if (this.db.playlists.length !== len) {
      this.saveData(this.db);
      return true;
    }
    return false;
  }

  public toggleChannelBlocked(channelId: string, blocked?: boolean): ChannelItem | null {
    const ch = this.db.channels.find(c => c.id === channelId);
    if (!ch) return null;
    ch.isBlocked = blocked !== undefined ? blocked : !ch.isBlocked;
    this.saveData(this.db);
    return ch;
  }

  public toggleVodBlocked(vodId: string, blocked?: boolean): VodItem | null {
    const item = this.db.vod.find(v => v.id === vodId);
    if (!item) return null;
    item.isBlocked = blocked !== undefined ? blocked : !item.isBlocked;
    this.saveData(this.db);
    return item;
  }

  public updatePlayerSettings(settings: Partial<PlayerSettings>): PlayerSettings {
    this.db.playerSettings = {
      ...this.db.playerSettings,
      ...settings,
    };
    this.saveData(this.db);
    return this.db.playerSettings;
  }

  public importXtreamContent(
    channels: ChannelItem[],
    vod: VodItem[],
    playlistMeta: {
      name: string;
      url: string;
      username?: string;
      serverUrl?: string;
      status?: string;
      expDate?: string;
    },
    replace = true
  ) {
    const plId = `pl_xtream_${Date.now()}`;
    const newPlaylist: IPTVPlaylist = {
      id: plId,
      name: playlistMeta.name || 'Servidor Xtream Codes',
      type: 'xtream',
      url: playlistMeta.url,
      username: playlistMeta.username || '',
      lastSynced: new Date().toISOString(),
      channelCount: channels.length,
      active: true,
    };

    // Deactivate other playlists if this is set as active
    this.db.playlists.forEach((p) => {
      p.active = false;
    });
    this.db.playlists.unshift(newPlaylist);

    if (replace && channels.length > 0) {
      this.db.channels = channels;
    } else if (channels.length > 0) {
      // Merge unique by URL or name
      const existingUrls = new Set(this.db.channels.map((c) => c.url));
      const toAdd = channels.filter((c) => !existingUrls.has(c.url));
      this.db.channels = [...this.db.channels, ...toAdd];
    }

    if (replace && vod.length > 0) {
      this.db.vod = vod;
    } else if (vod.length > 0) {
      const existingVodUrls = new Set(this.db.vod.map((v) => v.url));
      const toAddVod = vod.filter((v) => !existingVodUrls.has(v.url));
      this.db.vod = [...this.db.vod, ...toAddVod];
    }

    this.db.activePlaylistId = plId;
    this.db.activeXtreamSource = {
      id: plId,
      name: playlistMeta.name,
      serverUrl: playlistMeta.serverUrl || playlistMeta.url,
      username: playlistMeta.username,
      status: playlistMeta.status || 'Conectado',
      expDate: playlistMeta.expDate || 'Vigente',
      totalChannels: channels.length,
      totalVod: vod.length,
      lastSynced: new Date().toISOString(),
    };

    this.saveData(this.db);
    return {
      playlist: newPlaylist,
      channelsCount: this.db.channels.length,
      vodCount: this.db.vod.length,
      activeXtreamSource: this.db.activeXtreamSource,
    };
  }

  public setActivePlaylist(playlistId: string): boolean {
    const pl = this.db.playlists.find((p) => p.id === playlistId);
    if (!pl) return false;

    this.db.playlists.forEach((p) => {
      p.active = p.id === playlistId;
    });
    this.db.activePlaylistId = playlistId;

    if (this.db.activeXtreamSource && this.db.activeXtreamSource.id === playlistId) {
      // keep current
    } else {
      this.db.activeXtreamSource = {
        id: pl.id,
        name: pl.name,
        serverUrl: pl.url,
        username: pl.username,
        status: 'Activo',
        totalChannels: pl.channelCount,
        totalVod: this.db.vod.length,
        lastSynced: pl.lastSynced,
      };
    }

    this.saveData(this.db);
    return true;
  }

  public addDirectChannel(channel: { name: string; url: string; category?: string; logo?: string }) {
    const newCh: ChannelItem = {
      id: `custom_ch_${Date.now()}`,
      number: this.db.channels.length + 1,
      name: channel.name || `Canal Personalizado ${this.db.channels.length + 1}`,
      category: channel.category || 'Directo Xtream',
      logo: channel.logo || 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=120&auto=format&fit=crop&q=80',
      url: channel.url,
      resolution: '1080p Stream',
      isBlocked: false,
      epgNow: {
        title: channel.name,
        startTime: '00:00',
        endTime: '23:59',
        description: 'URL directa instruida para reproducción inmediata',
      },
      epgNext: {
        title: 'Programación continua',
        startTime: '23:59',
        endTime: '06:00',
        description: 'Transmisión sin interrupciones',
      },
    };
    this.db.channels.unshift(newCh);
    this.saveData(this.db);
    return newCh;
  }
}

