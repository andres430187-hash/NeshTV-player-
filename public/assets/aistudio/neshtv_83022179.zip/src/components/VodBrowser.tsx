import React, { useState } from 'react';
import { VodItem } from '../types/index.ts';
import {
  ArrowLeft,
  Play,
  Star,
  Clock,
  Film,
  Clapperboard,
  Search,
  Maximize2,
  X,
} from 'lucide-react';

interface VodBrowserProps {
  type: 'movie' | 'series';
  items: VodItem[];
  onBack: () => void;
}

export const VodBrowser: React.FC<VodBrowserProps> = ({ type, items, onBack }) => {
  const [selectedItem, setSelectedItem] = useState<VodItem | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('Todos');

  const filteredItems = items.filter((item) => {
    const isCorrectType = item.type === type;
    const matchCategory = activeCategory === 'Todos' || item.category.includes(activeCategory);
    const matchSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.synopsis.toLowerCase().includes(searchQuery.toLowerCase());
    return isCorrectType && matchCategory && matchSearch;
  });

  const categories = [
    'Todos',
    ...Array.from(new Set(items.filter((i) => i.type === type).map((i) => i.category))),
  ];

  return (
    <div className="relative min-h-screen w-full bg-black text-white p-4 md:p-8 flex flex-col select-none">
      {/* Top Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            data-action="back"
            data-tv-focus="true"
            data-focus-id="btn-vod-back"
            className="tv-focusable flex items-center gap-2 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-[#00F0FF] text-xs font-semibold text-zinc-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-[#00F0FF]" />
            <span>Volver al Menú</span>
          </button>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              {type === 'movie' ? (
                <>
                  <Film className="w-5 h-5 text-[#00F0FF]" />
                  <span>Películas (Movies VOD)</span>
                </>
              ) : (
                <>
                  <Clapperboard className="w-5 h-5 text-[#00F0FF]" />
                  <span>Series de Televisión</span>
                </>
              )}
            </h1>
            <p className="text-xs text-zinc-400">
              {filteredItems.length} títulos en alta definición disponibles
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder={`Buscar ${type === 'movie' ? 'película' : 'serie'}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto py-4 no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            data-tv-focus="true"
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeCategory === cat
                ? 'bg-[#00F0FF] text-black shadow-[0_0_12px_rgba(0,240,255,0.35)]'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid of Posters */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 py-2">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedItem(item)}
            data-tv-focus="true"
            data-focus-id={`vod-${item.id}`}
            tabIndex={0}
            className="tv-focusable group relative bg-[#121212] border border-zinc-800 hover:border-[#00F0FF] rounded-xl overflow-hidden cursor-pointer shadow-lg transition-all duration-200"
          >
            <div className="aspect-[2/3] w-full relative overflow-hidden bg-zinc-900">
              <img
                src={item.poster}
                alt={item.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />

              {/* Rating badge */}
              <div className="absolute top-2 right-2 bg-black/80 backdrop-blur-md px-1.5 py-0.5 rounded-md border border-zinc-700 flex items-center gap-1 text-[10px] font-bold text-amber-400">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                <span>{item.rating}</span>
              </div>

              {/* Play hover button */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                <div className="w-10 h-10 rounded-full bg-[#00F0FF] text-black flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
                  <Play className="w-5 h-5 ml-0.5 fill-current" />
                </div>
              </div>
            </div>

            <div className="p-2.5">
              <h3 className="text-xs font-bold text-white truncate group-hover:text-[#00F0FF] transition-colors">
                {item.title}
              </h3>
              <div className="flex items-center justify-between text-[10px] text-zinc-400 mt-1">
                <span>{item.year}</span>
                <span>{item.duration || `${item.seasons} Temporadas`}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Details & Playback Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-3xl bg-[#121212] border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
            {isPlaying ? (
              /* Video Player */
              <div className="relative aspect-video bg-black flex items-center justify-center">
                <video
                  src={selectedItem.url}
                  controls
                  autoPlay
                  className="w-full h-full object-contain"
                />
                <button
                  onClick={() => setIsPlaying(false)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-black/80 text-white hover:text-red-400 z-10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ) : (
              /* Info Preview */
              <div className="flex flex-col md:flex-row">
                <div className="w-full md:w-56 shrink-0 aspect-[2/3] bg-zinc-900 relative">
                  <img
                    src={selectedItem.poster}
                    alt={selectedItem.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="p-6 flex flex-col justify-between flex-1">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#00F0FF] uppercase tracking-wider">
                        {selectedItem.category}
                      </span>
                      <button
                        onClick={() => setSelectedItem(null)}
                        className="p-1 rounded-lg text-zinc-400 hover:text-white"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <h2 className="text-2xl font-black text-white mt-1">
                      {selectedItem.title}
                    </h2>

                    <div className="flex items-center gap-4 text-xs text-zinc-400 my-3">
                      <span className="flex items-center gap-1 text-amber-400 font-bold">
                        <Star className="w-3.5 h-3.5 fill-current" /> {selectedItem.rating}
                      </span>
                      <span>Año: {selectedItem.year}</span>
                      <span>
                        {selectedItem.duration || `${selectedItem.seasons} Temporadas / ${selectedItem.episodesCount} Episodios`}
                      </span>
                    </div>

                    <p className="text-xs text-zinc-300 leading-relaxed mb-6">
                      {selectedItem.synopsis}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setIsPlaying(true)}
                      data-tv-focus="true"
                      data-focus-id="btn-vod-play"
                      className="tv-focusable flex-1 py-3 px-4 rounded-xl bg-[#00F0FF] hover:bg-[#33f3ff] text-black font-extrabold text-xs tracking-wider flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.4)] cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>REPRODUCIR AHORA</span>
                    </button>
                    <button
                      onClick={() => setSelectedItem(null)}
                      className="py-3 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-semibold text-xs border border-zinc-800"
                    >
                      Cerrar
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
