import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { StorageService } from './src/server/storage.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);
  const storage = StorageService.getInstance();

  app.use(express.json());

  // Public endpoint for login screen footer info
  app.get('/api/public/info', (req, res) => {
    res.json(storage.getPublicInfo());
  });

  // Client authentication endpoint
  app.post('/api/auth/client-login', (req, res) => {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ success: false, message: 'Usuario y contraseña requeridos' });
    }

    const authResult = storage.authenticateClient(username, password);
    if (!authResult.success) {
      return res.status(authResult.suspended ? 403 : 401).json({
        success: false,
        suspended: authResult.suspended || false,
        message: authResult.message || 'Credenciales inválidas',
      });
    }

    const user = authResult.user!;
    const db = storage.getDb();

    // Filter out channels that are blocked globally or blocked specifically for this user
    const userBlockedSet = new Set(user.blockedChannels || []);
    const availableChannels = db.channels.filter(ch => !ch.isBlocked && !userBlockedSet.has(ch.id));

    // Floating message for this user or all
    let activeMessage = null;
    if (db.floatingMessage.active) {
      if (db.floatingMessage.targetUserId === 'all' || db.floatingMessage.targetUserId === user.id) {
        activeMessage = db.floatingMessage;
      }
    }

    const isAdmin = user.username.toLowerCase() === 'admin';
    const adminToken = isAdmin ? 'nesh_admin_token_' + Date.now() : null;

    res.json({
      success: true,
      isAdmin,
      adminToken,
      user: {
        id: user.id,
        username: user.username,
        expiryDate: user.expiryDate,
        status: user.status,
        notes: user.notes,
      },
      channels: availableChannels,
      vod: db.vod.filter(v => !v.isBlocked),
      contactNote: db.contactNote,
      floatingMessage: activeMessage,
      playerSettings: db.playerSettings,
    });
  });

  // Admin authentication endpoint
  app.post('/api/auth/admin-login', (req, res) => {
    const { username, password } = req.body || {};
    if (storage.authenticateAdmin(username, password)) {
      return res.json({
        success: true,
        token: 'nesh_admin_token_' + Date.now(),
        adminUser: 'admin',
      });
    }
    return res.status(401).json({
      success: false,
      message: 'Credenciales maestras incorrectas. Acceso denegado.',
    });
  });

  // Admin: Get all data
  app.get('/api/admin/data', (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.includes('nesh_admin_token_')) {
      return res.status(401).json({ error: 'Acceso no autorizado' });
    }
    res.json(storage.getDb());
  });

  // Admin: Create user
  app.post('/api/admin/users', (req, res) => {
    const { username, password, expiryDate, status, notes, blockedChannels } = req.body;
    if (!username || !password || !expiryDate) {
      return res.status(400).json({ error: 'Faltan campos obligatorios' });
    }
    const newUser = storage.addUser({
      username,
      password,
      expiryDate,
      status: status || 'active',
      notes: notes || '',
      blockedChannels: blockedChannels || [],
    });
    res.json({ success: true, user: newUser });
  });

  // Admin: Update user
  app.put('/api/admin/users/:id', (req, res) => {
    const updated = storage.updateUser(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json({ success: true, user: updated });
  });

  // Admin: Delete user
  app.delete('/api/admin/users/:id', (req, res) => {
    const ok = storage.deleteUser(req.params.id);
    if (!ok) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    res.json({ success: true });
  });

  // Admin: Update contact note
  app.post('/api/admin/contact-note', (req, res) => {
    const { note } = req.body;
    if (typeof note !== 'string') {
      return res.status(400).json({ error: 'Nota requerida' });
    }
    const updated = storage.updateContactNote(note);
    res.json({ success: true, contactNote: updated });
  });

  // Admin: Update floating message
  app.post('/api/admin/floating-message', (req, res) => {
    const updated = storage.updateFloatingMessage(req.body);
    res.json({ success: true, floatingMessage: updated });
  });

  // Admin: Add playlist
  app.post('/api/admin/playlists', (req, res) => {
    const { name, type, url, username, password, active } = req.body;
    if (!name || !url) {
      return res.status(400).json({ error: 'Nombre y URL requeridos' });
    }
    const pl = storage.addPlaylist({
      name,
      type: type || 'm3u',
      url,
      username: username || '',
      password: password || '',
      channelCount: 50,
      active: active !== undefined ? active : true,
    });
    res.json({ success: true, playlist: pl });
  });

  // Admin: Delete playlist
  app.delete('/api/admin/playlists/:id', (req, res) => {
    const ok = storage.deletePlaylist(req.params.id);
    res.json({ success: ok });
  });

  // Admin: Toggle channel blocked state
  app.put('/api/admin/channels/:id/toggle', (req, res) => {
    const ch = storage.toggleChannelBlocked(req.params.id, req.body.blocked);
    if (!ch) {
      return res.status(404).json({ error: 'Canal no encontrado' });
    }
    res.json({ success: true, channel: ch });
  });

  // Admin: Toggle VOD blocked state
  app.put('/api/admin/vod/:id/toggle', (req, res) => {
    const item = storage.toggleVodBlocked(req.params.id, req.body.blocked);
    if (!item) {
      return res.status(404).json({ error: 'Película/Serie no encontrada' });
    }
    res.json({ success: true, vod: item });
  });

  // Admin: Purge unpaid/expired users
  app.post('/api/admin/users/purge-unpaid', (req, res) => {
    const count = storage.deleteUnpaidUsers();
    res.json({ success: true, deletedCount: count });
  });

  // Admin: Update player settings
  app.post('/api/admin/settings', (req, res) => {
    const updated = storage.updatePlayerSettings(req.body);
    res.json({ success: true, playerSettings: updated });
  });

  // Setup Vite in development or static serve in production
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NeshTV Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
