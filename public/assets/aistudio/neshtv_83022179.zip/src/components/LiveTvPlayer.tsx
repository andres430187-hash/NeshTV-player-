import React, { useState, useEffect, useRef } from 'react';
import { ChannelItem, PlayerSettings } from '../types/index.ts';
import Hls from 'hls.js';
import {
  ArrowLeft,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Radio,
  Tv,
  Clock,
  Sparkles,
  Search,
  Filter,
  CheckCircle2,
  Sliders,
} from 'lucide-react';

interface LiveTvPlayerProps {
  channels: ChannelItem[];
  playerSettings: PlayerSettings;
  onBack: () => void;
  onOpenSettings: () => void;
}

export const LiveTvPlayer: React.FC<LiveTvPlayerProps> = ({
  channels,
  playerSettings,
  onBack,
  onOpenSettings,
}) => {
  const [selectedChannel, setSelectedChannel] = useState<ChannelItem>(channels[0] || null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '4:3' | 'cover'>('16:9');
  const [showOsd, setShowOsd] = useState(true);
  const [streamError, setStreamError] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const osdTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Extract categories
  const categories = ['Todos', ...Array.from(new Set(channels.map((c) => c.category)))];

  // Filter channels
  const filteredChannels = channels.filter((c) => {
    const matchCat = activeCategory === 'Todos' || c.category === activeCategory;
    const matchSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.number.toString().includes(searchQuery);
    return matchCat && matchSearch;
  });

  // Load stream when selected channel changes
  useEffect(() => {
    if (!selectedChannel || !videoRef.current) return;

    setStreamError(false);
    const video = videoRef.current;
    const streamUrl = selectedChannel.url;

    // Cleanup previous hls instance
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    if (streamUrl.includes('.m3u8') && Hls.isSupported()) {
      const hls = new Hls({
        maxBufferLength: playerSettings.bufferSize || 20,
        enableWorker: true,
      });
      hlsRef.current = hls;
      hls.loadSource(streamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().catch(() => setIsPlaying(false));
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          console.warn('HLS fatal error, falling back:', data);
          setStreamError(true);
        }
      });
    } else {
      // Direct video playback (MP4 or browser-native HLS)
      video.src = streamUrl;
      video.load();
      video.play().catch(() => setIsPlaying(false));
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [selectedChannel, playerSettings.bufferSize]);

  // Handle channel click:
  // If clicked channel is ALREADY selected -> go to FULLSCREEN (Requirement 5)
  // Else -> select channel and update preview
  const handleChannelSelect = (channel: ChannelItem) => {
    if (selectedChannel?.id === channel.id) {
      setIsFullscreen(true);
      triggerOsd();
    } else {
      setSelectedChannel(channel);
    }
  };

  const triggerOsd = () => {
    setShowOsd(true);
    if (osdTimerRef.current) clearTimeout(osdTimerRef.current);
    osdTimerRef.current = setTimeout(() => {
      setShowOsd(false);
    }, 4500);
  };

  const handleNextChannel = () => {
    const idx = filteredChannels.findIndex((c) => c.id === selectedChannel.id);
    if (idx !== -1 && idx < filteredChannels.length - 1) {
      setSelectedChannel(filteredChannels[idx + 1]);
      triggerOsd();
    }
  };

  const handlePrevChannel = () => {
    const idx = filteredChannels.findIndex((c) => c.id === selectedChannel.id);
    if (idx > 0) {
      setSelectedChannel(filteredChannels[idx - 1]);
      triggerOsd();
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  return (
    <div
      className={`relative w-full h-screen bg-black text-white flex flex-col overflow-hidden select-none ${
        isFullscreen ? 'p-0' : 'p-3 md:p-6'
      }`}
      onMouseMove={() => isFullscreen && triggerOsd()}
    >
      {/* FULLSCREEN TV MODE OVERLAY (Requirement 5) */}
      {isFullscreen ? (
        <div className="relative w-full h-full bg-black flex items-center justify-center">
          {/* Main Full-Screen Video */}
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted={isMuted}
            className={`w-full h-full ${
              aspectRatio === '16:9'
                ? 'object-contain aspect-video'
                : aspectRatio === '4:3'
                ? 'object-contain aspect-[4/3]'
                : 'object-cover'
            }`}
          />

          {streamError && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/80 p-6 text-center">
              <div className="max-w-md bg-[#121212] p-6 rounded-2xl border border-red-500/50 shadow-2xl">
                <Radio className="w-10 h-10 text-red-400 mx-auto mb-3 animate-pulse" />
                <h3 className="text-lg font-bold text-white">Reconectando con la señal en vivo...</h3>
                <p className="text-xs text-zinc-400 mt-2">
                  Optimizando búfer ({playerSettings.bufferSize}s) con decodificador {playerSettings.decoder.toUpperCase()}.
                </p>
                <button
                  onClick={() => handleChannelSelect(selectedChannel)}
                  className="mt-4 px-4 py-2 bg-[#00F0FF] text-black font-bold text-xs rounded-xl"
                >
                  Reintentar Canal
                </button>
              </div>
            </div>
          )}

          {/* TV Leanback OSD (On Screen Display) */}
          <div
            className={`absolute inset-0 pointer-events-none transition-opacity duration-300 flex flex-col justify-between p-6 ${
              showOsd ? 'opacity-100' : 'opacity-0'
            }`}
          >
            {/* Top OSD Bar */}
            <div className="pointer-events-auto flex items-center justify-between bg-black/75 backdrop-blur-md border border-zinc-800 rounded-2xl px-5 py-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsFullscreen(false)}
                  data-action="back"
                  className="p-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-white flex items-center gap-2 text-xs font-semibold"
                >
                  <ArrowLeft className="w-4 h-4 text-[#00F0FF]" />
                  <span>Salir Pantalla Completa</span>
                </button>

                <div className="flex items-center gap-2">
                  <span className="font-mono text-xl font-black text-[#00F0FF]">
                    CH {selectedChannel.number}
                  </span>
                  <span className="text-lg font-bold text-white">
                    {selectedChannel.name}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-bold bg-[#00F0FF]/15 text-[#00F0FF] px-2.5 py-1 rounded-lg border border-[#00F0FF]/30">
                  {selectedChannel.resolution || '1080p 60fps'}
                </span>
                <button
                  onClick={() =>
                    setAspectRatio(
                      aspectRatio === '16:9' ? '4:3' : aspectRatio === '4:3' ? 'cover' : '16:9'
                    )
                  }
                  className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-xs rounded-lg text-zinc-300"
                >
                  Ratio: {aspectRatio.toUpperCase()}
                </button>
              </div>
            </div>

            {/* Bottom OSD Bar: EPG details and quick navigation */}
            <div className="pointer-events-auto bg-black/85 backdrop-blur-lg border border-zinc-800/90 rounded-2xl p-5 shadow-[0_20px_50px_rgba(0,0,0,0.9)]">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-start gap-4">
                  <img
                    src={selectedChannel.logo}
                    alt={selectedChannel.name}
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 rounded-xl object-cover bg-zinc-900 border border-zinc-700 p-1"
                  />
                  <div>
                    <div className="flex items-center gap-2 text-xs text-[#00F0FF] font-semibold mb-1">
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                      <span>EN VIVO AHORA</span>
                      <span>·</span>
                      <span>{selectedChannel.epgNow.startTime} - {selectedChannel.epgNow.endTime}</span>
                    </div>
                    <h3 className="text-xl font-extrabold text-white">
                      {selectedChannel.epgNow.title}
                    </h3>
                    <p className="text-xs text-zinc-400 mt-1 line-clamp-1 max-w-2xl">
                      {selectedChannel.epgNow.description}
                    </p>
                  </div>
                </div>

                {/* Quick Channel Up / Down controls for remote */}
                <div className="flex items-center gap-2 self-end md:self-center">
                  <button
                    onClick={handlePrevChannel}
                    className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-xs font-bold text-zinc-200"
                  >
                    ▲ Canal Anterior
                  </button>
                  <button
                    onClick={handleNextChannel}
                    className="px-3 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-xs font-bold text-zinc-200"
                  >
                    ▼ Canal Siguiente
                  </button>
                  <button
                    onClick={() => setIsFullscreen(false)}
                    className="p-2 bg-[#00F0FF] text-black rounded-xl hover:bg-[#33f3ff]"
                    title="Minimizar a Split-view"
                  >
                    <Minimize className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* SPLIT VIEW (Requirement 5) */
        <div className="flex flex-col h-full gap-4">
          {/* Top Bar for Split View */}
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-3">
              <button
                onClick={onBack}
                data-action="back"
                data-tv-focus="true"
                data-focus-id="btn-live-back"
                className="tv-focusable flex items-center gap-2 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-[#00F0FF] text-xs font-semibold text-zinc-300 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-4 h-4 text-[#00F0FF]" />
                <span>Volver al Menú</span>
              </button>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight">TV en Vivo</span>
                <span className="text-xs bg-[#00F0FF]/15 text-[#00F0FF] px-2 py-0.5 rounded-md font-semibold">
                  {filteredChannels.length} disponibles
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={onOpenSettings}
                data-tv-focus="true"
                data-focus-id="btn-live-settings"
                className="tv-focusable flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-[#00F0FF] text-xs text-zinc-300 hover:text-[#00F0FF]"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Ajustes Decodificador ({playerSettings.decoder.toUpperCase()})</span>
              </button>
            </div>
          </div>

          {/* Split Content: Left Channels List (40%) | Right Preview Player & EPG (60%) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 min-h-0">
            {/* LEFT COLUMN: Channels List & Categories */}
            <div className="lg:col-span-5 flex flex-col h-full bg-[#101010] border border-zinc-800/90 rounded-2xl overflow-hidden p-3 shadow-xl">
              {/* Search input */}
              <div className="relative mb-2.5">
                <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Buscar canal o número..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-black/80 border border-zinc-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#00F0FF]"
                />
              </div>

              {/* Horizontal Category Badges */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-2.5 mb-2 border-b border-zinc-800/60 no-scrollbar">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    data-tv-focus="true"
                    className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                      activeCategory === cat
                        ? 'bg-[#00F0FF] text-black shadow-[0_0_10px_rgba(0,240,255,0.4)]'
                        : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Vertical Channels List */}
              <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
                {filteredChannels.length === 0 ? (
                  <div className="text-center py-12 text-zinc-500 text-xs">
                    No se encontraron canales en esta categoría
                  </div>
                ) : (
                  filteredChannels.map((ch) => {
                    const isSelected = selectedChannel?.id === ch.id;
                    return (
                      <div
                        key={ch.id}
                        onClick={() => handleChannelSelect(ch)}
                        data-tv-focus="true"
                        data-focus-id={`channel-${ch.id}`}
                        tabIndex={0}
                        className={`tv-focusable w-full p-2.5 rounded-xl cursor-pointer flex items-center justify-between gap-3 transition-all ${
                          isSelected
                            ? 'bg-[#00F0FF]/15 border-2 border-[#00F0FF] shadow-[0_0_15px_rgba(0,240,255,0.3)]'
                            : 'bg-zinc-900/60 hover:bg-zinc-900 border border-zinc-800/80 text-zinc-300'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {/* Channel number badge */}
                          <span
                            className={`font-mono text-xs font-bold px-2 py-1 rounded-lg ${
                              isSelected ? 'bg-[#00F0FF] text-black' : 'bg-black text-zinc-400'
                            }`}
                          >
                            {ch.number}
                          </span>

                          {/* Channel logo */}
                          <img
                            src={ch.logo}
                            alt={ch.name}
                            referrerPolicy="no-referrer"
                            className="w-9 h-9 rounded-lg object-cover bg-black border border-zinc-800 shrink-0"
                          />

                          {/* Channel name & EPG snippet */}
                          <div className="min-w-0 text-left">
                            <h4
                              className={`text-xs md:text-sm font-bold truncate ${
                                isSelected ? 'text-white' : 'text-zinc-200'
                              }`}
                            >
                              {ch.name}
                            </h4>
                            <p className="text-[11px] text-zinc-400 truncate mt-0.5">
                              {ch.epgNow.title}
                            </p>
                          </div>
                        </div>

                        {isSelected && (
                          <div className="flex items-center gap-1 shrink-0 text-[#00F0FF] text-[11px] font-bold">
                            <span className="hidden sm:inline">VER EN TV</span>
                            <Maximize className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* RIGHT COLUMN: Live Preview Player & EPG Program Details */}
            <div className="lg:col-span-7 flex flex-col h-full bg-[#101010] border border-zinc-800/90 rounded-2xl overflow-hidden p-3 md:p-4 shadow-xl">
              {/* Video Preview Box (Double-click or click full-screen button for TV Mode) */}
              <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden border border-zinc-800 shadow-2xl group">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted={isMuted}
                  className="w-full h-full object-contain"
                />

                {/* Overlay Click Hint */}
                <div
                  onClick={() => setIsFullscreen(true)}
                  className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
                  title="Haz clic para ver en Pantalla Completa"
                >
                  <div className="bg-[#00F0FF] text-black font-extrabold text-xs px-4 py-2 rounded-xl shadow-lg flex items-center gap-2">
                    <Maximize className="w-4 h-4" />
                    <span>PANTALLA COMPLETA (OK)</span>
                  </div>
                </div>

                {/* Top Badge on preview */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <div className="bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-lg border border-red-500/40 text-[11px] font-bold text-red-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                    <span>EN VIVO</span>
                  </div>
                  <span className="bg-black/70 backdrop-blur-md px-2 py-1 rounded-lg border border-zinc-800 text-[11px] text-zinc-300 font-mono">
                    CH {selectedChannel?.number}
                  </span>
                </div>

                {/* Bottom preview controls bar */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black via-black/80 to-transparent p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={togglePlay}
                      className="p-1.5 rounded-lg bg-zinc-800/80 text-white hover:text-[#00F0FF]"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={toggleMute}
                      className="p-1.5 rounded-lg bg-zinc-800/80 text-white hover:text-[#00F0FF]"
                    >
                      {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                    <span className="text-[11px] text-zinc-300 font-medium">
                      {selectedChannel?.name}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-zinc-900 border border-zinc-700 px-2 py-0.5 rounded text-[#00F0FF] font-bold">
                      {playerSettings.playbackFormat.toUpperCase()}
                    </span>
                    <button
                      onClick={() => setIsFullscreen(true)}
                      data-tv-focus="true"
                      data-focus-id="btn-preview-fullscreen"
                      className="tv-focusable p-1.5 rounded-lg bg-[#00F0FF] text-black font-bold hover:scale-105 transition-transform"
                      title="Pantalla Completa"
                    >
                      <Maximize className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Detailed EPG (Current & Next Program) */}
              {selectedChannel && (
                <div className="mt-4 flex-1 flex flex-col justify-between overflow-y-auto space-y-3">
                  {/* Current Program Box */}
                  <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3.5">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2 text-xs font-bold text-[#00F0FF]">
                        <Clock className="w-3.5 h-3.5" />
                        <span>PROGRAMA ACTUAL ({selectedChannel.epgNow.startTime} - {selectedChannel.epgNow.endTime})</span>
                      </div>
                      <span className="text-[10px] text-zinc-400 font-mono">En emisión</span>
                    </div>

                    <h3 className="text-base font-bold text-white mb-1">
                      {selectedChannel.epgNow.title}
                    </h3>
                    <p className="text-xs text-zinc-300 leading-relaxed">
                      {selectedChannel.epgNow.description}
                    </p>

                    {/* Progress bar simulation */}
                    <div className="w-full bg-zinc-800 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div className="bg-[#00F0FF] h-full rounded-full w-2/3 shadow-[0_0_8px_#00F0FF]" />
                    </div>
                  </div>

                  {/* Next Program Box */}
                  <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-xl p-3.5">
                    <div className="flex items-center gap-2 text-xs font-semibold text-zinc-400 mb-1">
                      <Clock className="w-3.5 h-3.5 text-zinc-500" />
                      <span>A CONTINUACIÓN ({selectedChannel.epgNext.startTime} - {selectedChannel.epgNext.endTime})</span>
                    </div>
                    <h4 className="text-sm font-semibold text-zinc-200">
                      {selectedChannel.epgNext.title}
                    </h4>
                    <p className="text-xs text-zinc-400 mt-1 line-clamp-2">
                      {selectedChannel.epgNext.description}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
