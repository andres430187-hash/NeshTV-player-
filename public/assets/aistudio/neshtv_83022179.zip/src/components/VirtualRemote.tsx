import React, { useState } from 'react';
import { useRemoteNavigation } from '../context/RemoteNavigationContext.tsx';
import {
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Home,
  Menu,
  Tv,
  Smartphone,
  Minimize2,
  Maximize2,
  HelpCircle,
} from 'lucide-react';

export const VirtualRemote: React.FC = () => {
  const { simulateKey, deviceMode, setDeviceMode, showVirtualRemote, setShowVirtualRemote } = useRemoteNavigation();
  const [isMinimized, setIsMinimized] = useState(false);
  const [showKeyboardHelp, setShowKeyboardHelp] = useState(false);

  if (!showVirtualRemote) {
    return (
      <button
        onClick={() => setShowVirtualRemote(true)}
        className="fixed bottom-4 right-4 z-50 flex items-center gap-2 bg-[#121212]/90 border border-[#00F0FF]/50 hover:border-[#00F0FF] text-white px-3 py-2 rounded-full shadow-[0_0_15px_rgba(0,240,255,0.25)] text-xs font-semibold backdrop-blur-md transition-all hover:scale-105"
        title="Mostrar Control Remoto Virtual"
      >
        <Tv className="w-4 h-4 text-[#00F0FF]" />
        <span>Control Remoto TV</span>
      </button>
    );
  }

  return (
    <div
      className={`fixed bottom-4 right-4 z-50 bg-[#0d0d0d]/95 backdrop-blur-xl border border-zinc-800 hover:border-[#00F0FF]/40 rounded-2xl shadow-[0_10px_35px_rgba(0,0,0,0.85)] transition-all duration-200 select-none ${
        isMinimized ? 'w-auto' : 'w-64 p-3.5'
      }`}
    >
      {/* Header bar */}
      <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-zinc-800/80">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#00F0FF] shadow-[0_0_6px_#00F0FF]" />
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">
            {isMinimized ? 'D-Pad' : 'Control NeshTV'}
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowKeyboardHelp(!showKeyboardHelp)}
            className="p-1 rounded text-zinc-400 hover:text-[#00F0FF] transition-colors"
            title="Ver teclas del teclado"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 rounded text-zinc-400 hover:text-white transition-colors"
            title={isMinimized ? 'Expandir' : 'Minimizar'}
          >
            {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => setShowVirtualRemote(false)}
            className="p-1 rounded text-zinc-400 hover:text-red-400 text-xs font-bold transition-colors ml-0.5"
            title="Ocultar control remoto"
          >
            ✕
          </button>
        </div>
      </div>

      {/* Mode switch */}
      {!isMinimized && (
        <div className="flex bg-black/60 p-1 rounded-lg border border-zinc-800 mb-3 text-[11px] font-medium">
          <button
            onClick={() => setDeviceMode('tv')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-1 rounded transition-colors ${
              deviceMode === 'tv'
                ? 'bg-[#00F0FF]/15 text-[#00F0FF] font-semibold border border-[#00F0FF]/40'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Tv className="w-3 h-3" />
            <span>Smart TV</span>
          </button>
          <button
            onClick={() => setDeviceMode('mobile')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-1 rounded transition-colors ${
              deviceMode === 'mobile'
                ? 'bg-[#00F0FF]/15 text-[#00F0FF] font-semibold border border-[#00F0FF]/40'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Smartphone className="w-3 h-3" />
            <span>Móvil Touch</span>
          </button>
        </div>
      )}

      {/* Keyboard instructions modal/card */}
      {showKeyboardHelp && !isMinimized && (
        <div className="bg-black/90 p-2.5 rounded-lg border border-[#00F0FF]/30 mb-3 text-[11px] space-y-1 text-zinc-300">
          <div className="font-bold text-[#00F0FF] text-xs">Teclas físicas compatibles:</div>
          <div className="flex justify-between">
            <span className="text-zinc-400">Navegación:</span>
            <span className="font-mono text-white">Flechas ↑ ↓ ← →</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-400">Seleccionar (OK):</span>
            <span className="font-mono text-white">Enter</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-400">Volver (Atrás):</span>
            <span className="font-mono text-white">Esc / Borrar</span>
          </div>
        </div>
      )}

      {/* D-Pad circle */}
      {!isMinimized ? (
        <div className="flex flex-col items-center">
          <div className="relative w-36 h-36 bg-zinc-900/90 rounded-full border border-zinc-700/80 shadow-[inset_0_2px_8px_rgba(0,0,0,0.8)] flex items-center justify-center p-2 my-1">
            {/* Up */}
            <button
              onClick={() => simulateKey('ArrowUp')}
              className="absolute top-1.5 w-10 h-8 flex items-center justify-center text-zinc-300 hover:text-[#00F0FF] active:scale-95 transition-all"
              title="Arriba (Flecha Arriba)"
            >
              <ChevronUp className="w-5 h-5" />
            </button>

            {/* Down */}
            <button
              onClick={() => simulateKey('ArrowDown')}
              className="absolute bottom-1.5 w-10 h-8 flex items-center justify-center text-zinc-300 hover:text-[#00F0FF] active:scale-95 transition-all"
              title="Abajo (Flecha Abajo)"
            >
              <ChevronDown className="w-5 h-5" />
            </button>

            {/* Left */}
            <button
              onClick={() => simulateKey('ArrowLeft')}
              className="absolute left-1.5 h-10 w-8 flex items-center justify-center text-zinc-300 hover:text-[#00F0FF] active:scale-95 transition-all"
              title="Izquierda (Flecha Izquierda)"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Right */}
            <button
              onClick={() => simulateKey('ArrowRight')}
              className="absolute right-1.5 h-10 w-8 flex items-center justify-center text-zinc-300 hover:text-[#00F0FF] active:scale-95 transition-all"
              title="Derecha (Flecha Derecha)"
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            {/* Center OK button */}
            <button
              onClick={() => simulateKey('Enter')}
              className="w-14 h-14 rounded-full bg-zinc-800 hover:bg-[#00F0FF] hover:text-black border border-zinc-700 hover:border-[#00F0FF] text-[#00F0FF] font-bold text-xs shadow-md active:scale-90 transition-all flex items-center justify-center"
              title="OK / Enter"
            >
              OK
            </button>
          </div>

          {/* Quick action buttons row */}
          <div className="grid grid-cols-3 gap-2 w-full mt-3">
            <button
              onClick={() => simulateKey('Back')}
              className="flex flex-col items-center justify-center py-2 px-1 bg-zinc-900/80 hover:bg-zinc-800 rounded-lg text-zinc-300 hover:text-white border border-zinc-800 transition-colors"
              title="Atrás (Esc / Backspace)"
            >
              <RotateCcw className="w-3.5 h-3.5 mb-1 text-zinc-400" />
              <span className="text-[10px]">Atrás</span>
            </button>
            <button
              onClick={() => simulateKey('Home')}
              className="flex flex-col items-center justify-center py-2 px-1 bg-zinc-900/80 hover:bg-zinc-800 rounded-lg text-zinc-300 hover:text-[#00F0FF] border border-zinc-800 transition-colors"
              title="Inicio / Dashboard"
            >
              <Home className="w-3.5 h-3.5 mb-1 text-[#00F0FF]" />
              <span className="text-[10px]">Inicio</span>
            </button>
            <button
              onClick={() => simulateKey('Menu')}
              className="flex flex-col items-center justify-center py-2 px-1 bg-zinc-900/80 hover:bg-zinc-800 rounded-lg text-zinc-300 hover:text-white border border-zinc-800 transition-colors"
              title="Menú"
            >
              <Menu className="w-3.5 h-3.5 mb-1 text-zinc-400" />
              <span className="text-[10px]">Menú</span>
            </button>
          </div>
        </div>
      ) : (
        /* Minimized quick cross */
        <div className="flex items-center gap-1.5 p-1">
          <button
            onClick={() => simulateKey('ArrowLeft')}
            className="p-1.5 rounded bg-zinc-800 text-zinc-200 hover:text-[#00F0FF]"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => simulateKey('Enter')}
            className="px-2.5 py-1 rounded bg-[#00F0FF] text-black font-bold text-xs"
          >
            OK
          </button>
          <button
            onClick={() => simulateKey('ArrowRight')}
            className="p-1.5 rounded bg-zinc-800 text-zinc-200 hover:text-[#00F0FF]"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => simulateKey('Back')}
            className="p-1.5 rounded bg-zinc-800 text-zinc-400 hover:text-white ml-1"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>
      )}
    </div>
  );
};
