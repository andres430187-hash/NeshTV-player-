import React, { useState, useEffect, useRef } from 'react';
import Hls from 'hls.js';
import {
  UserAccount,
  ChannelItem,
  VodItem,
  IPTVPlaylist,
  FloatingMessage,
  PlayerSettings,
} from '../types/index.ts';
import {
  ShieldCheck,
  Users,
  MessageSquare,
  Radio,
  Tv,
  Film,
  FileCode2,
  Lock,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  XCircle,
  Eye,
  EyeOff,
  Send,
  PhoneCall,
  Save,
  RotateCw,
  LogOut,
  AlertTriangle,
  Download,
  Copy,
  Check,
  Play,
  Pause,
  Activity,
  Filter,
  Volume2,
  VolumeX,
  Maximize,
} from 'lucide-react';

interface AdminPanelProps {
  initialAdminToken?: string;
  onClose: () => void;
  onRefreshData?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  initialAdminToken,
  onClose,
  onRefreshData,
}) => {
  // Master auth state
  const [isAdminAuth, setIsAdminAuth] = useState(!!initialAdminToken);
  const [adminUser, setAdminUser] = useState('admin');
  const [adminPass, setAdminPass] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [adminToken, setAdminToken] = useState<string | null>(initialAdminToken || null);

  // Active tab
  const [activeTab, setActiveTab] = useState<
    'users' | 'contact' | 'playlists' | 'channels' | 'vod' | 'messaging' | 'apk'
  >('users');

  // Server data
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [contactNote, setContactNote] = useState('');
  const [playlists, setPlaylists] = useState<IPTVPlaylist[]>([]);
  const [channels, setChannels] = useState<ChannelItem[]>([]);
  const [vod, setVod] = useState<VodItem[]>([]);

  // Monitoring & Testing states
  const [monitoredChannel, setMonitoredChannel] = useState<ChannelItem | null>(null);
  const [monitoredVod, setMonitoredVod] = useState<VodItem | null>(null);
  const [monitorStatus, setMonitorStatus] = useState<'playing' | 'buffering' | 'error' | 'idle'>('idle');
  const [isMonitorMuted, setIsMonitorMuted] = useState(true);
  const [userFilter, setUserFilter] = useState<'all' | 'active' | 'unpaid'>('all');

  const channelVideoRef = useRef<HTMLVideoElement | null>(null);
  const channelHlsRef = useRef<Hls | null>(null);
  const [floatingMsg, setFloatingMsg] = useState<FloatingMessage>({
    id: '1',
    text: '',
    sender: 'Administrador NeshTV',
    targetUserId: 'all',
    active: true,
    type: 'info',
    createdAt: '',
  });

  // UI helpers
  const [loading, setLoading] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  // User modal state
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [formUsername, setFormUsername] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formExpiry, setFormExpiry] = useState('');
  const [formStatus, setFormStatus] = useState<'active' | 'blocked'>('active');
  const [formNotes, setFormNotes] = useState('');

  // Playlist modal state
  const [showPlaylistModal, setShowPlaylistModal] = useState(false);
  const [plName, setPlName] = useState('');
  const [plType, setPlType] = useState<'m3u' | 'xtream'>('m3u');
  const [plUrl, setPlUrl] = useState('');
  const [plUser, setPlUser] = useState('');
  const [plPass, setPlPass] = useState('');

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleAdminLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoginError('');

    try {
      const res = await fetch('/api/auth/admin-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: adminUser, password: adminPass }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setIsAdminAuth(true);
        setAdminToken(data.token);
        loadAdminData(data.token);
      } else {
        setLoginError(data.message || 'Credenciales maestras inválidas');
      }
    } catch (err) {
      setLoginError('Error de conexión con el servidor');
    }
  };

  const loadAdminData = async (token: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/data', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users || []);
        setContactNote(data.contactNote || '');
        setPlaylists(data.playlists || []);
        setChannels(data.channels || []);
        setVod(data.vod || []);
        if (data.channels && data.channels.length > 0) {
          setMonitoredChannel((prev) => prev || data.channels[0]);
        }
        if (data.vod && data.vod.length > 0) {
          setMonitoredVod((prev) => prev || data.vod[0]);
        }
        if (data.floatingMessage) setFloatingMsg(data.floatingMessage);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Auto-load data if initialAdminToken is provided
  useEffect(() => {
    const token = initialAdminToken || adminToken;
    if (token) {
      setIsAdminAuth(true);
      setAdminToken(token);
      loadAdminData(token);
    }
  }, [initialAdminToken]);

  // Video testing monitor effect for Channels (Detects buffering, freezing and errors)
  const [uptimeSeconds, setUptimeSeconds] = useState(0);

  const retryMonitoredChannel = () => {
    if (!monitoredChannel || !channelVideoRef.current) return;
    setUptimeSeconds(0);
    setMonitorStatus('buffering');
    const video = channelVideoRef.current;
    if (channelHlsRef.current) {
      channelHlsRef.current.destroy();
      channelHlsRef.current = null;
    }
    const url = monitoredChannel.url;
    if (url.includes('.m3u8') && Hls.isSupported()) {
      const hls = new Hls({ maxBufferLength: 15, enableWorker: true });
      channelHlsRef.current = hls;
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().then(() => setMonitorStatus('playing')).catch(() => setMonitorStatus('buffering'));
      });
      hls.on(Hls.Events.ERROR, (_evt, data) => {
        if (data.fatal) setMonitorStatus('error');
      });
    } else {
      video.src = url;
      video.load();
      video.play().then(() => setMonitorStatus('playing')).catch(() => setMonitorStatus('buffering'));
    }
  };

  useEffect(() => {
    if (!monitoredChannel || !channelVideoRef.current) return;
    const video = channelVideoRef.current;
    const url = monitoredChannel.url;

    setUptimeSeconds(0);
    if (channelHlsRef.current) {
      channelHlsRef.current.destroy();
      channelHlsRef.current = null;
    }

    setMonitorStatus('buffering');

    const handlePlaying = () => setMonitorStatus('playing');
    const handleWaiting = () => setMonitorStatus('buffering');
    const handleStalled = () => setMonitorStatus('error');
    const handleError = () => setMonitorStatus('error');

    video.addEventListener('playing', handlePlaying);
    video.addEventListener('waiting', handleWaiting);
    video.addEventListener('stalled', handleStalled);
    video.addEventListener('error', handleError);

    if (url.includes('.m3u8') && Hls.isSupported()) {
      const hls = new Hls({ maxBufferLength: 15, enableWorker: true });
      channelHlsRef.current = hls;
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().then(() => setMonitorStatus('playing')).catch(() => setMonitorStatus('buffering'));
      });
      hls.on(Hls.Events.ERROR, (_evt, data) => {
        if (data.fatal) setMonitorStatus('error');
      });
    } else {
      video.src = url;
      video.load();
      video.play().then(() => setMonitorStatus('playing')).catch(() => setMonitorStatus('buffering'));
      video.onerror = () => setMonitorStatus('error');
    }

    const timer = setInterval(() => {
      if (video && !video.paused && !video.ended && video.readyState >= 3) {
        setUptimeSeconds((prev) => prev + 1);
      }
    }, 1000);

    return () => {
      clearInterval(timer);
      video.removeEventListener('playing', handlePlaying);
      video.removeEventListener('waiting', handleWaiting);
      video.removeEventListener('stalled', handleStalled);
      video.removeEventListener('error', handleError);
      if (channelHlsRef.current) {
        channelHlsRef.current.destroy();
        channelHlsRef.current = null;
      }
    };
  }, [monitoredChannel]);

  // User actions
  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken) return;

    if (!formUsername || !formPassword || !formExpiry) {
      alert('Por favor complete todos los campos');
      return;
    }

    try {
      if (editingUserId) {
        // Update user
        const res = await fetch(`/api/admin/users/${editingUserId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${adminToken}`,
          },
          body: JSON.stringify({
            username: formUsername,
            password: formPassword,
            expiryDate: formExpiry,
            status: formStatus,
            notes: formNotes,
          }),
        });
        if (res.ok) {
          showToast('Usuario actualizado correctamente');
          loadAdminData(adminToken);
          setShowUserModal(false);
        }
      } else {
        // Create user
        const res = await fetch('/api/admin/users', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${adminToken}`,
          },
          body: JSON.stringify({
            username: formUsername,
            password: formPassword,
            expiryDate: formExpiry,
            status: formStatus,
            notes: formNotes,
          }),
        });
        if (res.ok) {
          showToast('Usuario creado con éxito');
          loadAdminData(adminToken);
          setShowUserModal(false);
        }
      }
    } catch (err) {
      alert('Error guardando usuario');
    }
  };

  const handleToggleUserStatus = async (user: UserAccount) => {
    if (!adminToken) return;
    const newStatus = user.status === 'active' ? 'blocked' : 'active';
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        showToast(
          newStatus === 'blocked'
            ? `Usuario ${user.username} suspendido por falta de pago`
            : `Usuario ${user.username} reactivado con éxito`
        );
        loadAdminData(adminToken);
      }
    } catch (err) {
      alert('Error actualizando estado');
    }
  };

  const handleDeleteUser = async (id: string, name: string) => {
    if (!adminToken) return;
    if (name.toLowerCase() === 'admin') {
      showToast('⚠️ No es posible eliminar al Administrador Principal');
      return;
    }

    try {
      // Optimistic instant removal from table
      setUsers((prev) => prev.filter((u) => u.id !== id));
      showToast(`✓ Usuario "${name}" eliminado por completo`);

      const res = await fetch(`/api/admin/users/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (res.ok) {
        loadAdminData(adminToken);
      }
    } catch (err) {
      showToast('Error al eliminar usuario');
      loadAdminData(adminToken);
    }
  };

  const openCreateUserModal = () => {
    setEditingUserId(null);
    setFormUsername('');
    setFormPassword('');
    const futureDate = new Date();
    futureDate.setMonth(futureDate.getMonth() + 1);
    setFormExpiry(futureDate.toISOString().split('T')[0]);
    setFormStatus('active');
    setFormNotes('');
    setShowUserModal(true);
  };

  const openEditUserModal = (u: UserAccount) => {
    setEditingUserId(u.id);
    setFormUsername(u.username);
    setFormPassword(u.password || '');
    setFormExpiry(u.expiryDate);
    setFormStatus(u.status);
    setFormNotes(u.notes || '');
    setShowUserModal(true);
  };

  // Contact note update
  const handleSaveContactNote = async () => {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/contact-note', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ note: contactNote }),
      });
      if (res.ok) {
        showToast('Nota de contacto actualizada en tiempo real');
      }
    } catch (err) {
      alert('Error guardando nota');
    }
  };

  // Floating message update
  const handleSaveFloatingMessage = async () => {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/floating-message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify(floatingMsg),
      });
      if (res.ok) {
        showToast('Mensaje flotante enviado a la interfaz del usuario');
      }
    } catch (err) {
      alert('Error enviando mensaje');
    }
  };

  // Channel blocking toggle
  const handleToggleChannelBlock = async (ch: ChannelItem) => {
    if (!adminToken) return;
    try {
      const res = await fetch(`/api/admin/channels/${ch.id}/toggle`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ blocked: !ch.isBlocked }),
      });
      if (res.ok) {
        showToast(
          !ch.isBlocked ? `Canal ${ch.name} BLOQUEADO` : `Canal ${ch.name} DESBLOQUEADO`
        );
        loadAdminData(adminToken);
      }
    } catch (err) {
      alert('Error modificando canal');
    }
  };

  // VOD blocking toggle (Requirement: lo mismo con las películas)
  const handleToggleVodBlock = async (item: VodItem) => {
    if (!adminToken) return;
    try {
      const res = await fetch(`/api/admin/vod/${item.id}/toggle`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ blocked: !item.isBlocked }),
      });
      if (res.ok) {
        showToast(
          !item.isBlocked
            ? `Película "${item.title}" BLOQUEADA (Oculta para usuarios)`
            : `Película "${item.title}" HABILITADA (Visible en catálogo)`
        );
        loadAdminData(adminToken);
      }
    } catch (err) {
      alert('Error modificando película');
    }
  };

  // Purge unpaid users (Requirement: eliminar a los usuarios que no pagaron por completo)
  const handlePurgeUnpaidUsers = async () => {
    if (!adminToken) return;

    try {
      const todayStr = new Date().toISOString().split('T')[0];
      // Optimistic update: filter out blocked and expired accounts immediately
      setUsers((prev) =>
        prev.filter(
          (u) =>
            u.username.toLowerCase() === 'admin' ||
            (u.status !== 'blocked' && u.expiryDate >= todayStr)
        )
      );
      showToast('Eliminando usuarios no pagados de forma definitiva...');

      const res = await fetch('/api/admin/users/purge-unpaid', {
        method: 'POST',
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      const data = await res.json();
      if (res.ok) {
        showToast(`✓ ${data.deletedCount} usuario(s) no pagados eliminados por completo`);
        loadAdminData(adminToken);
      }
    } catch (err) {
      showToast('Error al eliminar usuarios no pagados');
      loadAdminData(adminToken);
    }
  };

  // Playlist actions
  const handleSavePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/playlists', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({
          name: plName,
          type: plType,
          url: plUrl,
          username: plUser,
          password: plPass,
        }),
      });
      if (res.ok) {
        showToast('Lista IPTV agregada correctamente');
        loadAdminData(adminToken);
        setShowPlaylistModal(false);
        setPlName('');
        setPlUrl('');
      }
    } catch (err) {
      alert('Error guardando lista');
    }
  };

  const handleDeletePlaylist = async (id: string) => {
    if (!adminToken) return;
    try {
      const res = await fetch(`/api/admin/playlists/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (res.ok) {
        showToast('Lista eliminada');
        loadAdminData(adminToken);
      }
    } catch (err) {
      alert('Error eliminando lista');
    }
  };

  const copyToClipboard = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  // If not authenticated as master admin, show login prompt
  if (!isAdminAuth) {
    return (
      <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-[#121212] border border-zinc-800 rounded-2xl p-6 md:p-8 shadow-[0_20px_50px_rgba(0,0,0,0.95)]">
          <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-white">Panel de Administración Privado</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-zinc-400 hover:text-white"
            >
              ✕
            </button>
          </div>

          <p className="text-xs text-zinc-400 mt-3 mb-6">
            Acceso restringido para el control de usuarios, listas IPTV, bloqueo de canales y notas institucionales.
          </p>

          {loginError && (
            <div className="mb-4 p-3 rounded-xl bg-red-950/40 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-400 mb-1 uppercase tracking-wider">
                Usuario Maestro
              </label>
              <input
                type="text"
                value={adminUser}
                onChange={(e) => setAdminUser(e.target.value)}
                placeholder="admin"
                className="w-full px-3.5 py-2.5 bg-black border border-zinc-800 rounded-xl text-sm text-white focus:outline-none focus:border-[#00F0FF]"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-400 mb-1 uppercase tracking-wider">
                Contraseña Maestra
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={adminPass}
                  onChange={(e) => setAdminPass(e.target.value)}
                  placeholder="Ingresa tu contraseña maestra"
                  className="w-full pl-3.5 pr-10 py-2.5 bg-black border border-zinc-800 rounded-xl text-sm text-white focus:outline-none focus:border-[#00F0FF]"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-zinc-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="w-1/3 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-xs font-bold text-zinc-400"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="w-2/3 py-2.5 rounded-xl bg-[#00F0FF] hover:bg-[#33f3ff] text-black font-bold text-xs tracking-wide shadow-[0_0_15px_rgba(0,240,255,0.4)] flex items-center justify-center gap-2 cursor-pointer"
              >
                <Lock className="w-4 h-4" />
                <span>ACCEDER AL PANEL</span>
              </button>
            </div>
          </form>

          <div className="mt-4 pt-3 border-t border-zinc-800/80 text-[11px] text-zinc-500 text-center flex items-center justify-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-[#00F0FF]" />
            <span>Acceso confidencial y restringido exclusivamente para el propietario</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex flex-col text-white select-none overflow-hidden">
      {/* Toast alert */}
      {toastMsg && (
        <div className="fixed top-5 right-5 z-50 bg-[#00F0FF] text-black font-bold text-xs px-4 py-2.5 rounded-xl shadow-[0_0_20px_rgba(0,240,255,0.5)] flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Top Navbar */}
      <header className="px-6 py-3.5 bg-[#0e0e0e] border-b border-zinc-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-base tracking-tight flex items-center gap-2">
              <span>NeshTV</span>
              <span className="text-[#00F0FF] text-xs font-mono uppercase bg-black px-2 py-0.5 rounded border border-[#00F0FF]/40">
                Web Admin Panel
              </span>
            </div>
            <span className="text-[11px] text-zinc-400">
              Administración Centralizada de Usuarios, Listas M3U y Canales
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => adminToken && loadAdminData(adminToken)}
            className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-[#00F0FF] border border-zinc-800 transition-colors"
            title="Recargar datos"
          >
            <RotateCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#00F0FF]' : ''}`} />
          </button>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-semibold text-zinc-300 hover:text-white"
          >
            Volver a la App
          </button>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="px-6 bg-[#0a0a0a] border-b border-zinc-800/80 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'users', label: 'Gestión de Usuarios', icon: Users, count: users.length },
          { id: 'channels', label: 'Monitor & Bloqueo Canales', icon: Tv, count: channels.length },
          { id: 'vod', label: 'Películas & Series (VOD)', icon: Film, count: vod.length },
          { id: 'playlists', label: 'Listas IPTV (M3U)', icon: Radio, count: playlists.length },
          { id: 'contact', label: 'Nota de Contacto', icon: PhoneCall },
          { id: 'messaging', label: 'Mensajería Flotante', icon: MessageSquare },
          { id: 'apk', label: 'Guía Compilación APK', icon: FileCode2 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
                isActive
                  ? 'border-[#00F0FF] text-[#00F0FF] bg-[#00F0FF]/5'
                  : 'border-transparent text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isActive ? 'bg-[#00F0FF] text-black font-bold' : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Main Tab Content */}
      <main className="flex-1 overflow-y-auto p-6 bg-[#060606]">
        {/* TAB 1: GESTIÓN DE USUARIOS */}
        {activeTab === 'users' && (
          <div className="max-w-6xl mx-auto space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-2 border-b border-zinc-800/80">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#00F0FF]" />
                  <span>Usuarios y Suscripciones NeshTV</span>
                </h3>
                <p className="text-xs text-zinc-400">
                  Control de pagos: suspende o elimina cuentas vencidas para restringir el acceso
                </p>
              </div>

              <div className="flex items-center gap-2.5 flex-wrap">
                {/* Purge Unpaid Users Button */}
                <button
                  type="button"
                  onClick={handlePurgeUnpaidUsers}
                  className="px-3.5 py-2 bg-red-950 hover:bg-red-900 border border-red-700 text-red-200 font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-[0_0_15px_rgba(239,68,68,0.3)] transition-all cursor-pointer"
                  title="Eliminar todos los usuarios con suscripción vencida o bloqueados"
                >
                  <Trash2 className="w-4 h-4 text-red-400" />
                  <span>ELIMINAR USUARIOS SIN PAGAR</span>
                </button>

                <button
                  onClick={openCreateUserModal}
                  className="px-4 py-2 bg-[#00F0FF] hover:bg-[#33f3ff] text-black font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,240,255,0.35)] cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>NUEVO USUARIO</span>
                </button>
              </div>
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setUserFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  userFilter === 'all'
                    ? 'bg-[#00F0FF] text-black shadow-[0_0_10px_rgba(0,240,255,0.3)]'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                }`}
              >
                Todos ({users.length})
              </button>
              <button
                onClick={() => setUserFilter('active')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  userFilter === 'active'
                    ? 'bg-emerald-500 text-black font-bold'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                }`}
              >
                Al Día / Activos ({users.filter((u) => u.status === 'active' && new Date(u.expiryDate) >= new Date()).length})
              </button>
              <button
                onClick={() => setUserFilter('unpaid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  userFilter === 'unpaid'
                    ? 'bg-red-500 text-white font-bold'
                    : 'bg-zinc-900 text-red-400 hover:text-red-300 border border-red-900/60'
                }`}
              >
                ⚠️ No Pagados / Vencidos ({users.filter((u) => u.status === 'blocked' || new Date(u.expiryDate) < new Date()).length})
              </button>
            </div>

            {/* Users Table */}
            <div className="bg-[#101010] border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-black/60 border-b border-zinc-800 text-zinc-400 uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Usuario</th>
                      <th className="py-3 px-4">Contraseña</th>
                      <th className="py-3 px-4">Vencimiento</th>
                      <th className="py-3 px-4">Estado de Pago</th>
                      <th className="py-3 px-4">Notas / Plan</th>
                      <th className="py-3 px-4 text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/60">
                    {users
                      .filter((u) => {
                        const isExpired = new Date(u.expiryDate) < new Date();
                        const isUnpaid = u.status === 'blocked' || isExpired;
                        if (userFilter === 'active') return u.status === 'active' && !isExpired;
                        if (userFilter === 'unpaid') return isUnpaid;
                        return true;
                      })
                      .map((u) => {
                        const isExpired = new Date(u.expiryDate) < new Date();
                      return (
                        <tr key={u.id} className="hover:bg-zinc-900/50 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-[#00F0FF]" />
                            <span>{u.username}</span>
                          </td>
                          <td className="py-3.5 px-4 font-mono text-zinc-300">
                            {u.password}
                          </td>
                          <td className="py-3.5 px-4 font-mono">
                            <span className={isExpired ? 'text-red-400 font-bold' : 'text-zinc-300'}>
                              {u.expiryDate}
                            </span>
                            {isExpired && (
                              <span className="ml-2 text-[10px] bg-red-950 text-red-300 px-1.5 py-0.5 rounded border border-red-800">
                                Vencido
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4">
                            {u.status === 'active' ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800">
                                <CheckCircle2 className="w-3 h-3" /> Activo
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-red-950/80 text-red-400 border border-red-800">
                                <XCircle className="w-3 h-3" /> Suspendido
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-zinc-400 max-w-xs truncate">
                            {u.notes || '—'}
                          </td>
                          <td className="py-3.5 px-4 text-right space-x-2">
                            {/* Toggle Block / Unblock */}
                            <button
                              onClick={() => handleToggleUserStatus(u)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors ${
                                u.status === 'active'
                                  ? 'bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800/80'
                                  : 'bg-emerald-950/60 hover:bg-emerald-900 text-emerald-300 border border-emerald-800/80'
                              }`}
                              title={
                                u.status === 'active'
                                  ? 'Bloquear acceso por falta de pago'
                                  : 'Reactivar acceso'
                              }
                            >
                              {u.status === 'active' ? 'Suspender' : 'Reactivar'}
                            </button>
                            <button
                              onClick={() => openEditUserModal(u)}
                              className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                              title="Editar usuario"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteUser(u.id, u.username)}
                              className="p-1.5 rounded-lg bg-zinc-800 hover:bg-red-950 text-zinc-400 hover:text-red-400"
                              title="Eliminar usuario"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: EDITOR DE NOTA DE CONTACTO (Requirement 3: Editor de Nota de Contacto) */}
        {activeTab === 'contact' && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="bg-[#101010] border border-zinc-800 rounded-2xl p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2.5 rounded-xl bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
                  <PhoneCall className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Nota de Contacto / Institucional (Pantalla de Inicio)
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Este texto se actualiza en tiempo real en el pie de página de la pantalla de inicio de la aplicación.
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                    Mensaje de atención al cliente / WhatsApp:
                  </label>
                  <textarea
                    rows={3}
                    value={contactNote}
                    onChange={(e) => setContactNote(e.target.value)}
                    placeholder="Ej: Para solicitar nuevas cuentas, renovaciones o soporte técnico, contáctanos vía WhatsApp al +52 55 1234 5678"
                    className="w-full bg-black border border-zinc-800 rounded-xl p-3 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#00F0FF] leading-relaxed"
                  />
                </div>

                {/* Live Preview */}
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block mb-2">
                    Vista previa de cómo lo verán los clientes en el Login:
                  </span>
                  <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-3 flex items-center gap-2.5 text-xs text-zinc-300">
                    <PhoneCall className="w-4 h-4 text-[#00F0FF] shrink-0" />
                    <span>{contactNote || 'Sin nota de contacto configurada'}</span>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleSaveContactNote}
                    className="px-5 py-2.5 bg-[#00F0FF] hover:bg-[#33f3ff] text-black font-bold text-xs rounded-xl flex items-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.4)] cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>GUARDAR NOTA EN TIEMPO REAL</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: GESTIÓN DE LISTAS IPTV (M3U / XTREAM) */}
        {activeTab === 'playlists' && (
          <div className="max-w-5xl mx-auto space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Listas y Servidores IPTV</h3>
                <p className="text-xs text-zinc-400">
                  Registra y administra URLs M3U o credenciales de servidores Xtream Codes externos
                </p>
              </div>
              <button
                onClick={() => setShowPlaylistModal(true)}
                className="px-4 py-2 bg-[#00F0FF] hover:bg-[#33f3ff] text-black font-bold text-xs rounded-xl flex items-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.35)] cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>AGREGAR LISTA IPTV</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {playlists.map((pl) => (
                <div
                  key={pl.id}
                  className="bg-[#101010] border border-zinc-800 rounded-2xl p-4 flex flex-col justify-between shadow-lg"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold bg-[#00F0FF]/15 text-[#00F0FF] px-2 py-0.5 rounded border border-[#00F0FF]/30 uppercase font-mono">
                        {pl.type.toUpperCase()}
                      </span>
                      <span className="text-[11px] text-zinc-400">
                        {pl.channelCount} Canales
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-white">{pl.name}</h4>
                    <p className="text-xs font-mono text-zinc-400 truncate mt-1 bg-black/60 p-1.5 rounded border border-zinc-800">
                      {pl.url}
                    </p>
                    <div className="text-[10px] text-zinc-500 mt-2">
                      Última sincronización: {new Date(pl.lastSynced).toLocaleString('es-ES')}
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between">
                    <button
                      onClick={() => showToast(`Sincronizando ${pl.name}...`)}
                      className="text-xs text-[#00F0FF] hover:underline flex items-center gap-1 font-semibold"
                    >
                      <RotateCw className="w-3.5 h-3.5" /> Sincronizar Ahora
                    </button>
                    <button
                      onClick={() => handleDeletePlaylist(pl.id)}
                      className="text-xs text-red-400 hover:text-red-300"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: MONITOR Y BLOQUEO DE CANALES */}
        {activeTab === 'channels' && (
          <div className="max-w-6xl mx-auto space-y-5">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Tv className="w-5 h-5 text-[#00F0FF]" />
                <span>Monitor de Señal en Vivo & Control de Canales</span>
              </h3>
              <p className="text-xs text-zinc-400">
                Prueba los canales en tiempo real para verificar si se cuelgan o tienen cortes. Los canales marcados con ❌ quedan 100% ocultos para los usuarios clientes.
              </p>
            </div>

            {/* LIVE SIGNAL MONITOR & FREEZE TESTER */}
            <div className="bg-[#101010] border border-zinc-800 rounded-2xl p-4 md:p-5 shadow-2xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#00F0FF]" />
                  <span className="text-xs font-bold uppercase tracking-wider text-white">
                    Monitor de Transmisión en Tiempo Real
                  </span>
                </div>

                {monitoredChannel && (
                  <div className="flex items-center gap-2">
                    {uptimeSeconds > 0 && monitorStatus === 'playing' && (
                      <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
                        ⏱️ {uptimeSeconds}s en reproducción continua
                      </span>
                    )}
                    <span
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold ${
                        monitorStatus === 'playing'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-700 shadow-[0_0_10px_rgba(52,211,153,0.3)]'
                          : monitorStatus === 'buffering'
                          ? 'bg-amber-950 text-amber-400 border border-amber-700 animate-pulse'
                          : monitorStatus === 'error'
                          ? 'bg-red-950 text-red-400 border border-red-700'
                          : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          monitorStatus === 'playing'
                            ? 'bg-emerald-400'
                            : monitorStatus === 'buffering'
                            ? 'bg-amber-400'
                            : 'bg-red-400'
                        }`}
                      />
                      {monitorStatus === 'playing'
                        ? 'Señal En Vivo (Fluida y Estable)'
                        : monitorStatus === 'buffering'
                        ? 'Verificando Búfer / Cargando...'
                        : monitorStatus === 'error'
                        ? '⚠️ Señal Colgada o Caída'
                        : 'En Espera'}
                    </span>
                  </div>
                )}
              </div>

              {monitoredChannel ? (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                  {/* Video Player */}
                  <div className="lg:col-span-7 bg-black rounded-xl overflow-hidden aspect-video border border-zinc-800 relative shadow-inner group">
                    <video
                      ref={channelVideoRef}
                      autoPlay
                      playsInline
                      muted={isMonitorMuted}
                      className="w-full h-full object-contain"
                    />

                    {/* Stream status overlay when buffering/error */}
                    {monitorStatus === 'error' && (
                      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center">
                        <AlertTriangle className="w-8 h-8 text-red-500 mb-2 animate-bounce" />
                        <p className="text-xs font-bold text-red-300">La señal se colgó o el enlace no responde</p>
                        <p className="text-[10px] text-zinc-400 mt-1 max-w-xs">Puedes bloquear este canal con ❌ para que los usuarios no lo vean en su app.</p>
                        <button
                          type="button"
                          onClick={retryMonitoredChannel}
                          className="mt-3 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold flex items-center gap-1.5 border border-zinc-700 cursor-pointer"
                        >
                          <RotateCw className="w-3.5 h-3.5" /> Reintentar Señal
                        </button>
                      </div>
                    )}

                    {/* Video Quick Controls */}
                    <div className="absolute bottom-3 right-3 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={retryMonitoredChannel}
                        className="p-2 rounded-lg bg-black/80 hover:bg-black text-zinc-300 hover:text-[#00F0FF] border border-zinc-700 transition-colors cursor-pointer"
                        title="Probar de nuevo / Reconectar flujo"
                      >
                        <RotateCw className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsMonitorMuted(!isMonitorMuted)}
                        className="p-2 rounded-lg bg-black/80 hover:bg-black text-zinc-300 hover:text-[#00F0FF] border border-zinc-700 transition-colors cursor-pointer"
                        title={isMonitorMuted ? 'Activar sonido de prueba' : 'Silenciar'}
                      >
                        {isMonitorMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => channelVideoRef.current?.requestFullscreen()}
                        className="p-2 rounded-lg bg-black/80 hover:bg-black text-zinc-300 hover:text-[#00F0FF] border border-zinc-700 transition-colors cursor-pointer"
                        title="Ver en pantalla completa"
                      >
                        <Maximize className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Channel badge on video */}
                    <div className="absolute top-3 left-3 flex items-center gap-2">
                      <span className="bg-black/80 px-2 py-0.5 rounded text-[11px] font-mono text-[#00F0FF] font-bold border border-zinc-700">
                        CH {monitoredChannel.number}
                      </span>
                      <span className="bg-black/80 px-2 py-0.5 rounded text-[11px] text-zinc-200 font-semibold border border-zinc-700">
                        {monitoredChannel.name}
                      </span>
                    </div>
                  </div>

                  {/* Channel stream details & controls */}
                  <div className="lg:col-span-5 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-[#00F0FF] font-bold">
                          {monitoredChannel.category}
                        </span>
                        <span className="text-[10px] text-zinc-400 font-mono">
                          {monitoredChannel.resolution || '1080p 60fps'}
                        </span>
                      </div>

                      <h4 className="text-base font-bold text-white">
                        {monitoredChannel.name}
                      </h4>
                      <p className="text-xs text-zinc-300 line-clamp-2">
                        {monitoredChannel.epgNow.title}
                      </p>

                      <div className="bg-black/80 p-2.5 rounded-xl border border-zinc-800 text-[11px] font-mono text-zinc-400 break-all space-y-1">
                        <div className="text-zinc-500 text-[10px] uppercase font-bold">URL Flujo M3U / HLS:</div>
                        <div className="text-zinc-300 truncate">{monitoredChannel.url}</div>
                      </div>

                      {/* State indicator for admin */}
                      <div className="p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs font-semibold mt-2">
                        <span>Visibilidad en la App:</span>
                        {monitoredChannel.isBlocked ? (
                          <span className="text-red-400 font-extrabold flex items-center gap-1">
                            ❌ BLOQUEADO (Oculto a clientes)
                          </span>
                        ) : (
                          <span className="text-emerald-400 font-extrabold flex items-center gap-1">
                            ✓ ACTIVO (Visible a clientes)
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-3">
                      <button
                        type="button"
                        onClick={() => handleToggleChannelBlock(monitoredChannel)}
                        className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                          monitoredChannel.isBlocked
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                            : 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.3)]'
                        }`}
                      >
                        {monitoredChannel.isBlocked ? (
                          <>
                            <CheckCircle2 className="w-4 h-4" />
                            <span>DESBLOQUEAR (MOSTRAR A CLIENTES)</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-4 h-4" />
                            <span>BLOQUEAR (OCULTAR TOTALMENTE)</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-zinc-500 text-xs">
                  Selecciona un canal de la lista inferior para probar la señal
                </div>
              )}
            </div>

            {/* Channels Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {channels.map((ch) => {
                const isSelected = monitoredChannel?.id === ch.id;
                return (
                  <div
                    key={ch.id}
                    className={`p-3 rounded-xl border transition-all flex flex-col justify-between gap-3 ${
                      ch.isBlocked
                        ? 'bg-red-950/20 border-red-800'
                        : isSelected
                        ? 'bg-zinc-900 border-[#00F0FF] shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                        : 'bg-[#101010] border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={ch.logo}
                        alt={ch.name}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-lg object-cover bg-black border border-zinc-800 shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-[10px] text-[#00F0FF] font-bold">
                            CH {ch.number}
                          </span>
                          <span className="text-[10px] text-zinc-400">{ch.category}</span>
                        </div>
                        <h4 className="text-xs font-bold text-white truncate">{ch.name}</h4>
                        <div className="flex items-center justify-between mt-1">
                          {ch.isBlocked ? (
                            <span className="text-[10px] font-extrabold text-red-400 bg-red-950/80 px-2 py-0.5 rounded border border-red-800">
                              ❌ BLOQUEADO (Oculto)
                            </span>
                          ) : (
                            <span className="text-[10px] font-extrabold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                              ✓ ACTIVO (Visible)
                            </span>
                          )}
                          <span className="text-[10px] text-zinc-500 font-mono">
                            {ch.resolution || '1080p'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-zinc-800/80">
                      <button
                        type="button"
                        onClick={() => setMonitoredChannel(ch)}
                        className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                          isSelected
                            ? 'bg-[#00F0FF] text-black font-bold'
                            : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200'
                        }`}
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>{isSelected ? 'Probando Señal' : 'Probar Señal'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleToggleChannelBlock(ch)}
                        className={`py-1.5 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          ch.isBlocked
                            ? 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-700'
                            : 'bg-red-950 hover:bg-red-900 text-red-300 border border-red-700'
                        }`}
                        title={
                          ch.isBlocked
                            ? 'Habilitar canal para los clientes'
                            : 'Bloquear y ocultar canal a clientes'
                        }
                      >
                        {ch.isBlocked ? 'Desbloquear' : '❌ Bloquear'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: PELÍCULAS Y SERIES (VOD) - Requirement: lo mismo con las películas */}
        {activeTab === 'vod' && (
          <div className="max-w-6xl mx-auto space-y-5">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Film className="w-5 h-5 text-[#00F0FF]" />
                <span>Control y Bloqueo de Películas & Series (VOD)</span>
              </h3>
              <p className="text-xs text-zinc-400">
                Verifica el catálogo y bloquea títulos que no deseas mostrar. Las películas con ❌ desaparecen de la app para todos los usuarios.
              </p>
            </div>

            {/* VOD Stream Tester */}
            {monitoredVod && (
              <div className="bg-[#101010] border border-zinc-800 rounded-2xl p-4 md:p-5 shadow-2xl">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-zinc-800">
                  <div className="flex items-center gap-2">
                    <Play className="w-4 h-4 text-[#00F0FF] fill-[#00F0FF]" />
                    <span className="text-xs font-bold uppercase tracking-wider text-white">
                      Probando Vídeo: {monitoredVod.title}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-zinc-400">{monitoredVod.category}</span>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                  <div className="lg:col-span-7 bg-black rounded-xl overflow-hidden aspect-video border border-zinc-800 relative">
                    <video
                      src={monitoredVod.url}
                      controls
                      autoPlay
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="lg:col-span-5 flex flex-col justify-between">
                    <div>
                      <h4 className="text-base font-bold text-white">{monitoredVod.title}</h4>
                      <p className="text-xs text-zinc-400 mt-1 line-clamp-3">{monitoredVod.synopsis}</p>
                      <div className="mt-2 text-xs text-zinc-400">
                        Año: <span className="text-white">{monitoredVod.year}</span> · Calificación: <span className="text-amber-400 font-bold">{monitoredVod.rating}</span>
                      </div>
                      <div className="p-2.5 rounded-xl border flex items-center justify-between text-xs font-semibold mt-3">
                        <span>Estado en Catálogo:</span>
                        {monitoredVod.isBlocked ? (
                          <span className="text-red-400 font-bold">❌ BLOQUEADA (Oculta a clientes)</span>
                        ) : (
                          <span className="text-emerald-400 font-bold">✓ DISPONIBLE EN CATÁLOGO</span>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleVodBlock(monitoredVod)}
                      className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all cursor-pointer mt-4 ${
                        monitoredVod.isBlocked
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                          : 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.3)]'
                      }`}
                    >
                      {monitoredVod.isBlocked ? '✓ DESBLOQUEAR Y MOSTRAR EN APP' : '❌ BLOQUEAR Y OCULTAR DE APP'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* VOD Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {vod.map((item) => (
                <div
                  key={item.id}
                  className={`bg-[#101010] border rounded-2xl overflow-hidden flex flex-col justify-between transition-all ${
                    item.isBlocked ? 'border-red-800/80 bg-red-950/10' : 'border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="aspect-[16/9] w-full bg-zinc-900 relative">
                    <img
                      src={item.poster}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 right-2">
                      {item.isBlocked ? (
                        <span className="bg-red-950 text-red-300 border border-red-700 text-[10px] font-extrabold px-2 py-0.5 rounded shadow">
                          ❌ BLOQUEADA
                        </span>
                      ) : (
                        <span className="bg-emerald-950 text-emerald-300 border border-emerald-700 text-[10px] font-extrabold px-2 py-0.5 rounded shadow">
                          ✓ DISPONIBLE
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="p-3">
                    <h5 className="text-xs font-bold text-white truncate">{item.title}</h5>
                    <div className="flex items-center justify-between text-[11px] text-zinc-400 mt-1">
                      <span>{item.category}</span>
                      <span>{item.year}</span>
                    </div>

                    <div className="flex items-center gap-2 mt-3 pt-2 border-t border-zinc-800">
                      <button
                        type="button"
                        onClick={() => setMonitoredVod(item)}
                        className="flex-1 py-1 px-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 flex items-center justify-center gap-1"
                      >
                        <Play className="w-3 h-3 fill-current" /> Probar
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleVodBlock(item)}
                        className={`py-1 px-2 rounded-lg text-xs font-bold transition-all ${
                          item.isBlocked
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                            : 'bg-red-950 text-red-300 border border-red-700'
                        }`}
                      >
                        {item.isBlocked ? 'Desbloquear' : '❌ Bloquear'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: SISTEMA DE MENSAJERÍA FLOTANTE (Requirement 3: Sistema de Mensajería Flotante) */}
        {activeTab === 'messaging' && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="bg-[#101010] border border-zinc-800 rounded-2xl p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2.5 rounded-xl bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Sistema de Mensajería Flotante (Notificaciones OSD)
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Redacta avisos instantáneos (recordatorios de vencimiento, mantenimientos o promociones) que flotarán en la pantalla del usuario.
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                    Texto del Mensaje:
                  </label>
                  <textarea
                    rows={3}
                    value={floatingMsg.text}
                    onChange={(e) =>
                      setFloatingMsg((prev) => ({ ...prev, text: e.target.value }))
                    }
                    placeholder="Ej: Aviso NeshTV: Tu suscripción vence en 3 días. Por favor comunícate a soporte para renovar y no perder el servicio."
                    className="w-full bg-black border border-zinc-800 rounded-xl p-3 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#00F0FF] leading-relaxed"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                      Remitente visible:
                    </label>
                    <input
                      type="text"
                      value={floatingMsg.sender}
                      onChange={(e) =>
                        setFloatingMsg((prev) => ({ ...prev, sender: e.target.value }))
                      }
                      className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00F0FF]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                      Destinatario:
                    </label>
                    <select
                      value={floatingMsg.targetUserId || 'all'}
                      onChange={(e) =>
                        setFloatingMsg((prev) => ({ ...prev, targetUserId: e.target.value }))
                      }
                      className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00F0FF]"
                    >
                      <option value="all">Todos los usuarios (Broadcast)</option>
                      {users.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.username} ({u.status})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* State toggle */}
                <div className="flex items-center gap-3 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold">
                    <input
                      type="checkbox"
                      checked={floatingMsg.active}
                      onChange={(e) =>
                        setFloatingMsg((prev) => ({ ...prev, active: e.target.checked }))
                      }
                      className="w-4 h-4 accent-[#00F0FF] rounded cursor-pointer"
                    />
                    <span>Activar visualización del mensaje en la pantalla del usuario</span>
                  </label>
                </div>

                {/* Live Preview */}
                <div className="mt-4 pt-4 border-t border-zinc-800">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block mb-2">
                    Vista previa del banner flotante:
                  </span>
                  <div className="bg-gradient-to-r from-[#00F0FF]/15 via-zinc-900 to-black/80 border border-[#00F0FF]/40 rounded-xl p-3 flex items-center justify-between gap-3 shadow-[0_0_15px_rgba(0,240,255,0.2)]">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-[#00F0FF]/20 text-[#00F0FF] shrink-0">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-wider text-[#00F0FF]">
                          {floatingMsg.sender}
                        </div>
                        <div className="text-xs text-zinc-200">
                          {floatingMsg.text || 'Texto del mensaje no redactado'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] bg-black/60 px-2 py-0.5 rounded text-[#00F0FF] font-mono">
                      {floatingMsg.targetUserId === 'all' ? 'Broadcast' : 'Directo'}
                    </span>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleSaveFloatingMessage}
                    className="px-5 py-2.5 bg-[#00F0FF] hover:bg-[#33f3ff] text-black font-bold text-xs rounded-xl flex items-center gap-2 shadow-[0_0_15px_rgba(0,240,255,0.4)] cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>PUBLICAR MENSAJE FLOTANTE</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: GUÍA DE COMPILACIÓN APK (Móvil y Android TV / TV Box) */}
        {activeTab === 'apk' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-[#101010] border border-zinc-800 rounded-2xl p-6 shadow-xl">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2.5 rounded-xl bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30">
                  <FileCode2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Guía Técnica de Compilación APK (Android Smartphone & Android TV / TV Box)
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Instrucciones completas para empaquetar NeshTV en APK nativo compatible con Google Play Store y sideloading en TV Box
                  </p>
                </div>
              </div>

              {/* Step 1: Capacitor setup */}
              <div className="space-y-4 text-xs text-zinc-300">
                <div className="p-4 bg-black/70 border border-zinc-800 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-[#00F0FF]">
                      Paso 1: Instalación de Capacitor para Android
                    </span>
                    <button
                      onClick={() =>
                        copyToClipboard(
                          `npm install @capacitor/core @capacitor/cli @capacitor/android\nnpx cap init "NeshTV" "com.neshtv.iptv" --web-dir dist\nnpx cap add android`,
                          'cap1'
                        )
                      }
                      className="text-zinc-400 hover:text-white flex items-center gap-1 text-[11px]"
                    >
                      {copiedSection === 'cap1' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>Copiar Comandos</span>
                    </button>
                  </div>
                  <pre className="font-mono text-zinc-300 bg-zinc-950 p-3 rounded-lg overflow-x-auto text-[11px] leading-relaxed">
{`# 1. Instalar dependencias Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Inicializar proyecto Capacitor
npx cap init "NeshTV" "com.neshtv.iptv" --web-dir dist

# 3. Compilar la aplicación web NeshTV
npm run build

# 4. Agregar la plataforma Android
npx cap add android`}
                  </pre>
                </div>

                {/* Step 2: AndroidManifest.xml for Android TV */}
                <div className="p-4 bg-black/70 border border-zinc-800 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-[#00F0FF]">
                      Paso 2: Configuración del AndroidManifest.xml (Android TV & TV Box Leanback)
                    </span>
                    <button
                      onClick={() =>
                        copyToClipboard(
                          `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.neshtv.iptv">

    <!-- Requerido para Android TV y TV Box -->
    <uses-feature
        android:name="android.software.leanback"
        android:required="false" />
    <uses-feature
        android:name="android.hardware.touchscreen"
        android:required="false" />
    <uses-feature
        android:name="android.hardware.microphone"
        android:required="false" />

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:banner="@drawable/neshtv_tv_banner"
        android:label="NeshTV"
        android:theme="@style/AppTheme.NoActionBar"
        android:usesCleartextTraffic="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:launchMode="singleTask"
            android:screenOrientation="sensorLandscape">
            
            <!-- Lanzador estándar para Smartphones Android -->
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <!-- Lanzador Leanback para Smart TV y Android TV Box -->
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`,
                          'manifest'
                        )
                      }
                      className="text-zinc-400 hover:text-white flex items-center gap-1 text-[11px]"
                    >
                      {copiedSection === 'manifest' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>Copiar AndroidManifest</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-zinc-400 mb-2">
                    En <code>android/app/src/main/AndroidManifest.xml</code>, habilita soporte híbrido (móvil y TV):
                  </p>
                  <pre className="font-mono text-zinc-300 bg-zinc-950 p-3 rounded-lg overflow-x-auto text-[11px] leading-relaxed max-h-56">
{`<!-- Habilitar Leanback sin restringir móviles -->
<uses-feature android:name="android.software.leanback" android:required="false" />
<uses-feature android:name="android.hardware.touchscreen" android:required="false" />

<!-- Intent filter para launcher de Android TV -->
<intent-filter>
    <action android:name="android.intent.action.MAIN" />
    <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
</intent-filter>`}
                  </pre>
                </div>

                {/* Step 3: Compilar APK */}
                <div className="p-4 bg-black/70 border border-zinc-800 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-[#00F0FF]">
                      Paso 3: Compilar APK Release / Debug
                    </span>
                    <button
                      onClick={() =>
                        copyToClipboard(
                          `npm run build\nnpx cap copy\ncd android\n./gradlew assembleRelease`,
                          'build'
                        )
                      }
                      className="text-zinc-400 hover:text-white flex items-center gap-1 text-[11px]"
                    >
                      {copiedSection === 'build' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>Copiar</span>
                    </button>
                  </div>
                  <pre className="font-mono text-zinc-300 bg-zinc-950 p-3 rounded-lg overflow-x-auto text-[11px] leading-relaxed">
{`# Sincronizar cambios en Android Studio
npm run build && npx cap copy

# Compilar APK con Gradle
cd android
./gradlew assembleDebug   # APK de prueba
./gradlew assembleRelease # APK optimizado para producción

# El APK generado se ubica en:
# android/app/build/outputs/apk/release/app-release-unsigned.apk`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* User Create/Edit Modal */}
      {showUserModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#121212] border border-zinc-800 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-4">
              <h3 className="text-base font-bold text-white">
                {editingUserId ? 'Editar Usuario' : 'Crear Nuevo Usuario NeshTV'}
              </h3>
              <button
                onClick={() => setShowUserModal(false)}
                className="text-zinc-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-zinc-400 font-semibold mb-1">Nombre de Usuario:</label>
                <input
                  type="text"
                  value={formUsername}
                  onChange={(e) => setFormUsername(e.target.value)}
                  placeholder="Ej: cliente_vip"
                  className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                  required
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">Contraseña:</label>
                <input
                  type="text"
                  value={formPassword}
                  onChange={(e) => setFormPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                  required
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">Fecha de Vencimiento:</label>
                <input
                  type="date"
                  value={formExpiry}
                  onChange={(e) => setFormExpiry(e.target.value)}
                  className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                  required
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">Estado de la cuenta:</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as any)}
                  className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                >
                  <option value="active">Activo (Acceso Permitido)</option>
                  <option value="blocked">Suspendido (Falta de Pago / Bloqueado)</option>
                </select>
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">Notas / Plan:</label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Ej: 3 Pantallas Full HD"
                  className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowUserModal(false)}
                  className="px-4 py-2 rounded-xl bg-zinc-900 text-zinc-400 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#00F0FF] text-black font-bold hover:bg-[#33f3ff] shadow-[0_0_12px_rgba(0,240,255,0.4)]"
                >
                  Guardar Usuario
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Playlist Create Modal */}
      {showPlaylistModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#121212] border border-zinc-800 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-4">
              <h3 className="text-base font-bold text-white">Agregar Lista IPTV / M3U</h3>
              <button
                onClick={() => setShowPlaylistModal(false)}
                className="text-zinc-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSavePlaylist} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-zinc-400 font-semibold mb-1">Nombre Descriptivo:</label>
                <input
                  type="text"
                  value={plName}
                  onChange={(e) => setPlName(e.target.value)}
                  placeholder="Ej: Servidor IPTV Primario"
                  className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                  required
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">Tipo de Lista:</label>
                <select
                  value={plType}
                  onChange={(e) => setPlType(e.target.value as any)}
                  className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                >
                  <option value="m3u">Enlace M3U / M3U8 Directo</option>
                  <option value="xtream">Xtream Codes API Server</option>
                </select>
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">URL del Proveedor:</label>
                <input
                  type="text"
                  value={plUrl}
                  onChange={(e) => setPlUrl(e.target.value)}
                  placeholder="http://server.iptv.com:8080/get.php?..."
                  className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                  required
                />
              </div>

              {plType === 'xtream' && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-zinc-400 font-semibold mb-1">Usuario Xtream:</label>
                    <input
                      type="text"
                      value={plUser}
                      onChange={(e) => setPlUser(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                    />
                  </div>
                  <div>
                    <label className="block text-zinc-400 font-semibold mb-1">Contraseña:</label>
                    <input
                      type="password"
                      value={plPass}
                      onChange={(e) => setPlPass(e.target.value)}
                      className="w-full bg-black border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#00F0FF]"
                    />
                  </div>
                </div>
              )}

              <div className="pt-3 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowPlaylistModal(false)}
                  className="px-4 py-2 rounded-xl bg-zinc-900 text-zinc-400 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#00F0FF] text-black font-bold hover:bg-[#33f3ff] shadow-[0_0_12px_rgba(0,240,255,0.4)]"
                >
                  Agregar Lista
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
