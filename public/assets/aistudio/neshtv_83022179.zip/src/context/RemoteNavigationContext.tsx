import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';

interface RemoteNavigationContextType {
  deviceMode: 'tv' | 'mobile';
  setDeviceMode: (mode: 'tv' | 'mobile') => void;
  focusedId: string | null;
  setFocusedId: (id: string | null) => void;
  simulateKey: (key: string) => void;
  showVirtualRemote: boolean;
  setShowVirtualRemote: (show: boolean | ((prev: boolean) => boolean)) => void;
  activeScreen: string;
  setActiveScreen: (screen: string) => void;
}

const RemoteNavigationContext = createContext<RemoteNavigationContextType | undefined>(undefined);

export const RemoteNavigationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [deviceMode, setDeviceMode] = useState<'tv' | 'mobile'>('tv');
  const [focusedId, setFocusedId] = useState<string | null>(null);
  const [showVirtualRemote, setShowVirtualRemote] = useState<boolean>(true);
  const [activeScreen, setActiveScreen] = useState<string>('login');
  const lastKeyTimeRef = useRef<number>(0);

  const handleSpatialMove = useCallback((direction: 'up' | 'down' | 'left' | 'right') => {
    // Find all focusable elements visible in DOM
    const focusables = Array.from(
      document.querySelectorAll<HTMLElement>('[data-tv-focus="true"], .tv-focusable, button:not([disabled]), input:not([disabled]), a[href]')
    ).filter(el => {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).display !== 'none' && window.getComputedStyle(el).visibility !== 'hidden';
    });

    if (focusables.length === 0) return;

    const currentFocused = document.activeElement as HTMLElement;
    let currentIndex = focusables.indexOf(currentFocused);

    if (currentIndex === -1) {
      // Find element matching focusedId or default to first
      if (focusedId) {
        const found = focusables.find(el => el.getAttribute('data-focus-id') === focusedId || el.id === focusedId);
        if (found) {
          found.focus();
          setFocusedId(found.getAttribute('data-focus-id') || found.id || null);
          return;
        }
      }
      focusables[0].focus();
      setFocusedId(focusables[0].getAttribute('data-focus-id') || focusables[0].id || null);
      return;
    }

    const currentRect = currentFocused.getBoundingClientRect();
    const currentCenter = {
      x: currentRect.left + currentRect.width / 2,
      y: currentRect.top + currentRect.height / 2,
    };

    // Calculate best candidate in the given direction
    let bestCandidate: HTMLElement | null = null;
    let minDistance = Infinity;

    for (const el of focusables) {
      if (el === currentFocused) continue;
      const rect = el.getBoundingClientRect();
      const center = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
      };

      const dx = center.x - currentCenter.x;
      const dy = center.y - currentCenter.y;

      let isDirectionValid = false;
      let primaryDist = 0;
      let secondaryDist = 0;

      if (direction === 'up' && dy < -5) {
        isDirectionValid = true;
        primaryDist = Math.abs(dy);
        secondaryDist = Math.abs(dx);
      } else if (direction === 'down' && dy > 5) {
        isDirectionValid = true;
        primaryDist = Math.abs(dy);
        secondaryDist = Math.abs(dx);
      } else if (direction === 'left' && dx < -5) {
        isDirectionValid = true;
        primaryDist = Math.abs(dx);
        secondaryDist = Math.abs(dy);
      } else if (direction === 'right' && dx > 5) {
        isDirectionValid = true;
        primaryDist = Math.abs(dx);
        secondaryDist = Math.abs(dy);
      }

      if (isDirectionValid) {
        // Favor elements along the primary movement axis
        const score = primaryDist + secondaryDist * 1.8;
        if (score < minDistance) {
          minDistance = score;
          bestCandidate = el;
        }
      }
    }

    // Fallback if 2D spatial doesn't find next element in direction
    if (!bestCandidate) {
      if (direction === 'down' || direction === 'right') {
        const nextIdx = (currentIndex + 1) % focusables.length;
        bestCandidate = focusables[nextIdx];
      } else {
        const prevIdx = (currentIndex - 1 + focusables.length) % focusables.length;
        bestCandidate = focusables[prevIdx];
      }
    }

    if (bestCandidate) {
      bestCandidate.focus();
      bestCandidate.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
      setFocusedId(bestCandidate.getAttribute('data-focus-id') || bestCandidate.id || null);
    }
  }, [focusedId]);

  const simulateKey = useCallback((key: string) => {
    const active = document.activeElement as HTMLElement;

    switch (key) {
      case 'ArrowUp':
        handleSpatialMove('up');
        break;
      case 'ArrowDown':
        handleSpatialMove('down');
        break;
      case 'ArrowLeft':
        handleSpatialMove('left');
        break;
      case 'ArrowRight':
        handleSpatialMove('right');
        break;
      case 'Enter':
      case 'Select':
        if (active) {
          active.click();
        }
        break;
      case 'Escape':
      case 'Backspace':
      case 'Back':
        // Trigger back action
        const backBtn = document.querySelector<HTMLElement>('[data-action="back"]');
        if (backBtn) {
          backBtn.click();
        } else {
          window.dispatchEvent(new CustomEvent('nesh:back'));
        }
        break;
      case 'Home':
        const homeBtn = document.querySelector<HTMLElement>('[data-action="home"]');
        if (homeBtn) {
          homeBtn.click();
        } else {
          window.dispatchEvent(new CustomEvent('nesh:home'));
        }
        break;
      case 'Menu':
        window.dispatchEvent(new CustomEvent('nesh:menu'));
        break;
      default:
        break;
    }
  }, [handleSpatialMove]);

  // Global keyboard listeners for TV Box remote keys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing text into an input field, UNLESS it's arrow navigation
      const isInput = e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement;
      
      if (isInput) {
        if (e.key === 'Enter') {
          // let form submit or trigger enter
          return;
        }
        if (e.key === 'Escape') {
          (e.target as HTMLElement).blur();
          return;
        }
        // Let user type normally
        if (!['ArrowUp', 'ArrowDown'].includes(e.key)) {
          return;
        }
      }

      const keysToHandle = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Enter', 'Escape', 'Backspace'];
      if (keysToHandle.includes(e.key)) {
        // Prevent default browser scrolling when navigating with D-pad
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
          e.preventDefault();
        }

        const now = Date.now();
        // Debounce slightly to prevent accidental double-jumps
        if (now - lastKeyTimeRef.current < 50) return;
        lastKeyTimeRef.current = now;

        if (e.key === 'Backspace' && !isInput) {
          e.preventDefault();
          simulateKey('Back');
          return;
        }

        simulateKey(e.key);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [simulateKey]);

  return (
    <RemoteNavigationContext.Provider
      value={{
        deviceMode,
        setDeviceMode,
        focusedId,
        setFocusedId,
        simulateKey,
        showVirtualRemote,
        setShowVirtualRemote,
        activeScreen,
        setActiveScreen,
      }}
    >
      {children}
    </RemoteNavigationContext.Provider>
  );
};

export const useRemoteNavigation = () => {
  const context = useContext(RemoteNavigationContext);
  if (!context) {
    throw new Error('useRemoteNavigation must be used within a RemoteNavigationProvider');
  }
  return context;
};
