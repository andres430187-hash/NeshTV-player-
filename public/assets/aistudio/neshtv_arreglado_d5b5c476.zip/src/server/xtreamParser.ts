import { ChannelItem, VodItem } from '../types/index.ts';

export interface XtreamCredentials {
  serverUrl: string;
  username: string;
  password: string;
  outputFormat?: 'm3u8' | 'ts';
}

export interface XtreamReadResult {
  success: boolean;
  works: boolean;
  statusCode?: number;
  latencyMs?: number;
  message: string;
  errorDetail?: string;
  serverInfo?: {
    url: string;
    port?: string;
    serverProtocol?: string;
    timezone?: string;
    rtmpPort?: string;
  };
  userInfo?: {
    username: string;
    status: string;
    expDate?: string;
    maxConnections?: string | number;
    activeCons?: string | number;
    isTrial?: string | boolean;
  };
  channels: ChannelItem[];
  vod: VodItem[];
  stats: {
    totalChannels: number;
    totalVod: number;
    categories: string[];
  };
  sourceUrl: string;
}

/**
 * Parses any Xtream URL, get.php link, or player_api.php link
 * into its server, username, password components.
 */
export function parseXtreamUrl(inputUrl: string, fallbackUser = '', fallbackPass = ''): XtreamCredentials {
  let cleanUrl = inputUrl.trim();
  let username = fallbackUser.trim();
  let password = fallbackPass.trim();
  let outputFormat: 'm3u8' | 'ts' = 'm3u8';

  try {
    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      cleanUrl = 'http://' + cleanUrl;
    }
    const parsed = new URL(cleanUrl);

    // Check query params: username, password, user, pass
    const qUser = parsed.searchParams.get('username') || parsed.searchParams.get('user');
    const qPass = parsed.searchParams.get('password') || parsed.searchParams.get('pass');
    const qOutput = parsed.searchParams.get('output');

    if (qUser) username = qUser;
    if (qPass) password = qPass;
    if (qOutput === 'ts' || qOutput === 'm3u8') outputFormat = qOutput;

    // Check if user/pass are in pathname e.g. /live/username/password/stream.ts
    const parts = parsed.pathname.split('/').filter(Boolean);
    if ((parts[0] === 'live' || parts[0] === 'movie' || parts[0] === 'series') && parts.length >= 3) {
      if (!username) username = parts[1];
      if (!password) password = parts[2];
    }

    const serverUrl = `${parsed.protocol}//${parsed.host}`;
    return { serverUrl, username, password, outputFormat };
  } catch {
    return {
      serverUrl: cleanUrl.replace(/\/+$/, ''),
      username,
      password,
      outputFormat,
    };
  }
}

/**
 * Fetches Xtream Codes API or M3U playlist from given URL/credentials
 */
export async function readXtreamContent(
  rawUrl: string,
  user = '',
  pass = ''
): Promise<XtreamReadResult> {
  const startTime = Date.now();
  const { serverUrl, username, password, outputFormat } = parseXtreamUrl(rawUrl, user, pass);

  // Headers standard for IPTV Smarters / VLC to avoid anti-bot blocks
  const headers = {
    'User-Agent': 'IPTVSmartersPro/3.1.5 (Linux; Android 12) VLC/3.0.18',
    Accept: '*/*',
    Connection: 'keep-alive',
  };

  const fetchWithTimeout = async (url: string, timeoutMs = 9000) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, { headers, signal: controller.signal });
      clearTimeout(timer);
      return res;
    } catch (err: any) {
      clearTimeout(timer);
      throw err;
    }
  };

  let lastStatusCode = 0;

  // STRATEGY 1: Xtream Codes JSON API (player_api.php)
  if (username && password && serverUrl) {
    try {
      const authApiUrl = `${serverUrl}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
      const authRes = await fetchWithTimeout(authApiUrl, 6000);
      lastStatusCode = authRes.status;

      if (authRes.ok) {
        const authData: any = await authRes.json();
        const userInfo = authData?.user_info;
        const serverInfo = authData?.server_info;

        // If Xtream returned valid user_info
        if (userInfo && userInfo.auth !== 0) {
          const latencyMs = Date.now() - startTime;

          // Fetch Live Categories
          let liveCatMap = new Map<string, string>();
          try {
            const catRes = await fetchWithTimeout(
              `${serverUrl}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&action=get_live_categories`,
              5000
            );
            if (catRes.ok) {
              const cats: any = await catRes.json();
              if (Array.isArray(cats)) {
                cats.forEach((c) => liveCatMap.set(String(c.category_id), c.category_name));
              }
            }
          } catch {
            // Non-critical if categories fail
          }

          // Fetch Live Streams
          let channels: ChannelItem[] = [];
          try {
            const streamsRes = await fetchWithTimeout(
              `${serverUrl}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&action=get_live_streams`,
              12000
            );
            if (streamsRes.ok) {
              const streams: any = await streamsRes.json();
              if (Array.isArray(streams)) {
                const streamExt = 'ts';
                channels = streams.map((s: any, idx: number) => {
                  const catName = liveCatMap.get(String(s.category_id)) || 'General';
                  const streamUrl = `${serverUrl}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${s.stream_id}.${streamExt}`;
                  return {
                    id: `xtream_ch_${s.stream_id || idx + 1}`,
                    number: s.num ? parseInt(s.num, 10) : idx + 1,
                    name: s.name || `Canal ${idx + 1}`,
                    category: catName,
                    logo:
                      s.stream_icon && s.stream_icon.startsWith('http')
                        ? s.stream_icon
                        : 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=120&auto=format&fit=crop&q=80',
                    url: streamUrl,
                    resolution: s.name && s.name.includes('FHD') ? '1080p FHD' : s.name && s.name.includes('HD') ? '720p HD' : 'Auto / Adaptable',
                    isBlocked: false,
                    epgNow: {
                      title: s.name || 'Emisión en directo',
                      startTime: '00:00',
                      endTime: '23:59',
                      description: `Señal en vivo proveniente de ${serverUrl} (${catName})`,
                    },
                    epgNext: {
                      title: 'Continuación de programación',
                      startTime: '23:59',
                      endTime: '06:00',
                      description: 'Programación automática 24/7 en alta definición.',
                    },
                  };
                });
              }
            }
          } catch (streamErr) {
            console.warn('Could not fetch get_live_streams:', streamErr);
          }

          // Fetch VOD Streams (Movies) and Series separately
          let movies: VodItem[] = [];
          try {
            const vodRes = await fetchWithTimeout(
              `${serverUrl}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&action=get_vod_streams`,
              10000
            );
            if (vodRes.ok) {
              const vodStreams: any = await vodRes.json();
              if (Array.isArray(vodStreams)) {
                movies = vodStreams.map((v: any, idx: number) => {
                  const ext = v.container_extension || 'mp4';
                  const streamUrl = `${serverUrl}/movie/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${v.stream_id}.${ext}`;
                  return {
                    id: `xtream_vod_${v.stream_id || idx + 1}`,
                    title: v.name || `Película ${idx + 1}`,
                    category: v.category_name || 'Películas Estreno',
                    type: 'movie',
                    year: v.year ? parseInt(v.year, 10) : 2026,
                    rating: v.rating ? String(v.rating) : '8.5',
                    poster:
                      v.stream_icon && v.stream_icon.startsWith('http')
                        ? v.stream_icon
                        : 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&auto=format&fit=crop&q=80',
                    synopsis: v.plot || v.name || 'Película disponible en el servidor Xtream.',
                    duration: v.duration || '1h 45m',
                    url: streamUrl,
                    isBlocked: false,
                  };
                });
              }
            }
          } catch (vodErr) {
            console.warn('Could not fetch get_vod_streams:', vodErr);
          }

          // Fetch Series
          let seriesList: VodItem[] = [];
          try {
            const seriesRes = await fetchWithTimeout(
              `${serverUrl}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&action=get_series`,
              10000
            );
            if (seriesRes.ok) {
              const seriesData: any = await seriesRes.json();
              if (Array.isArray(seriesData)) {
                seriesList = seriesData.map((s: any, idx: number) => {
                  const seriesId = s.series_id || s.id || idx + 1;
                  const streamUrl = `${serverUrl}/series/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${seriesId}.mp4`;
                  return {
                    id: `xtream_series_${seriesId}`,
                    title: s.name || `Serie ${idx + 1}`,
                    category: s.category_name || 'Series en Español',
                    type: 'series',
                    year: s.releaseDate ? parseInt(s.releaseDate, 10) : 2026,
                    rating: s.rating ? String(s.rating) : '8.8',
                    poster:
                      s.cover && s.cover.startsWith('http')
                        ? s.cover
                        : 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&auto=format&fit=crop&q=80',
                    synopsis: s.plot || s.name || 'Serie disponible en el servidor Xtream.',
                    seasons: s.seasons ? parseInt(s.seasons, 10) : 1,
                    url: streamUrl,
                    isBlocked: false,
                  };
                });
              }
            }
          } catch (seriesErr) {
            console.warn('Could not fetch get_series:', seriesErr);
          }

          const vod = [...movies, ...seriesList];

          // Format expiration date
          let expDateStr = 'Ilimitado / No especificado';
          if (userInfo.exp_date && userInfo.exp_date !== 'null') {
            const expTimestamp = parseInt(userInfo.exp_date, 10);
            if (!isNaN(expTimestamp)) {
              expDateStr = new Date(expTimestamp * 1000).toISOString().split('T')[0];
            } else {
              expDateStr = String(userInfo.exp_date);
            }
          }

          const categoriesSet = new Set<string>();
          channels.forEach((c) => categoriesSet.add(c.category));
          vod.forEach((v) => categoriesSet.add(v.category));

          return {
            success: true,
            works: true,
            statusCode: 200,
            latencyMs,
            message: `¡URL Xtream FUNCIONA CORRECTAMENTE! Respuesta en ${latencyMs}ms. Se importaron ${channels.length} canales en vivo y ${vod.length} títulos VOD.`,
            serverInfo: {
              url: serverUrl,
              port: serverInfo?.port,
              serverProtocol: serverInfo?.server_protocol,
              timezone: serverInfo?.timezone,
              rtmpPort: serverInfo?.rtmp_port,
            },
            userInfo: {
              username: userInfo.username || username,
              status: userInfo.status || 'Active',
              expDate: expDateStr,
              maxConnections: userInfo.max_connections || '1',
              activeCons: userInfo.active_cons || '0',
              isTrial: userInfo.is_trial,
            },
            channels,
            vod,
            stats: {
              totalChannels: channels.length,
              totalVod: vod.length,
              categories: Array.from(categoriesSet),
            },
            sourceUrl: rawUrl,
          };
        } else if (userInfo && userInfo.auth === 0) {
          const latencyMs = Date.now() - startTime;
          return {
            success: false,
            works: false,
            statusCode: 401,
            latencyMs,
            message: `LA URL NO FUNCIONA: El servidor Xtream respondió pero denegó el acceso (Error de Autenticación). Usuario o contraseña incorrectos.`,
            errorDetail: 'auth === 0',
            channels: [],
            vod: [],
            stats: { totalChannels: 0, totalVod: 0, categories: [] },
            sourceUrl: rawUrl,
          };
        }
      } else {
        lastStatusCode = authRes.status;
      }
    } catch (apiErr: any) {
      console.warn('Xtream API probe error, will fallback to M3U parser:', apiErr?.message || apiErr);
    }
  }

  // STRATEGY 2: M3U / M3U_PLUS parser (get.php or direct .m3u link or direct stream)
  try {
    let m3uTargetUrl = rawUrl;
    if (username && password && (!rawUrl.includes('get.php') && !rawUrl.includes('.m3u'))) {
      m3uTargetUrl = `${serverUrl}/get.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&type=m3u_plus&output=${outputFormat}`;
    }

    const m3uRes = await fetchWithTimeout(m3uTargetUrl, 12000);
    lastStatusCode = m3uRes.status;

    if (!m3uRes.ok) {
      const latencyMs = Date.now() - startTime;
      let failReason = `Código HTTP ${m3uRes.status}`;
      if (m3uRes.status === 401) failReason = 'Error 401: Usuario o contraseña incorrectos.';
      if (m3uRes.status === 403) failReason = 'Error 403: Acceso prohibido o bloqueado por el proveedor.';
      if (m3uRes.status === 404) failReason = 'Error 404: Archivo de lista o servidor no encontrado en esta URL.';
      if (m3uRes.status >= 500) failReason = `Error ${m3uRes.status}: El servidor del proveedor está caído o saturado.`;

      return {
        success: false,
        works: false,
        statusCode: m3uRes.status,
        latencyMs,
        message: `LA URL NO FUNCIONA: ${failReason}`,
        errorDetail: `HTTP ${m3uRes.status}`,
        channels: [],
        vod: [],
        stats: { totalChannels: 0, totalVod: 0, categories: [] },
        sourceUrl: rawUrl,
      };
    }

    const m3uText = await m3uRes.text();
    const latencyMs = Date.now() - startTime;

    // Check if it's a full M3U playlist with #EXTINF
    if (m3uText.includes('#EXTINF')) {
      const parsedData = parseM3uText(m3uText, serverUrl);
      return {
        success: true,
        works: true,
        statusCode: 200,
        latencyMs,
        message: `¡URL FUNCIONA CORRECTAMENTE! Lista M3U procesada en ${latencyMs}ms. Se encontraron ${parsedData.channels.length} canales y ${parsedData.vod.length} títulos VOD.`,
        serverInfo: {
          url: serverUrl,
        },
        userInfo: {
          username: username || 'M3U User',
          status: 'Active',
          expDate: 'Activa',
        },
        channels: parsedData.channels,
        vod: parsedData.vod,
        stats: {
          totalChannels: parsedData.channels.length,
          totalVod: parsedData.vod.length,
          categories: parsedData.categories,
        },
        sourceUrl: rawUrl,
      };
    }

    // Check if it's an HLS stream manifest (#EXTM3U + #EXT-X- or direct stream)
    if (m3uText.includes('#EXTM3U') || rawUrl.includes('.m3u8') || rawUrl.includes('.ts')) {
      const singleChannel: ChannelItem = {
        id: `direct_ch_${Date.now()}`,
        number: 1,
        name: 'Transmisión IPTV Directa',
        category: 'Flujo Directo',
        logo: 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=120&auto=format&fit=crop&q=80',
        url: rawUrl,
        resolution: '1080p Stream',
        isBlocked: false,
        epgNow: {
          title: 'Transmisión en directo',
          startTime: '00:00',
          endTime: '23:59',
          description: `Flujo HLS directo sincronizado desde ${rawUrl}`,
        },
        epgNext: {
          title: 'Emisión continua',
          startTime: '23:59',
          endTime: '06:00',
          description: 'Programación ininterrumpida.',
        },
      };

      return {
        success: true,
        works: true,
        statusCode: 200,
        latencyMs,
        message: `¡URL FUNCIONA CORRECTAMENTE! Flujo HLS detectado y verificado (Respuesta en ${latencyMs}ms). Canal listo para reproducir.`,
        serverInfo: { url: serverUrl },
        userInfo: { username: 'Direct Stream', status: 'Active', expDate: 'Activa' },
        channels: [singleChannel],
        vod: [],
        stats: {
          totalChannels: 1,
          totalVod: 0,
          categories: ['Flujo Directo'],
        },
        sourceUrl: rawUrl,
      };
    }

    // Response didn't match known format
    return {
      success: false,
      works: false,
      statusCode: 200,
      latencyMs,
      message: `LA URL NO FUNCIONA: El servidor respondió pero el contenido no es una lista M3U válida ni un flujo de vídeo reconocible. (Respuesta: ${m3uText.slice(0, 120)}...)`,
      errorDetail: 'Invalid content format (No #EXTM3U or #EXTINF found)',
      channels: [],
      vod: [],
      stats: { totalChannels: 0, totalVod: 0, categories: [] },
      sourceUrl: rawUrl,
    };
  } catch (m3uErr: any) {
    const latencyMs = Date.now() - startTime;
    const errMsg = m3uErr?.message || '';
    let userMsg = 'Tiempo de espera agotado o URL inaccesible.';

    if (m3uErr.name === 'AbortError' || errMsg.includes('abort')) {
      userMsg = 'Tiempo de espera agotado (Timeout tras 10 segundos). El servidor IPTV no respondió. Verifica que esté en línea.';
    } else if (errMsg.includes('ENOTFOUND') || errMsg.includes('getaddrinfo')) {
      userMsg = 'Dominio o dirección no encontrada. Verifica que la URL esté bien escrita.';
    } else if (errMsg.includes('ECONNREFUSED')) {
      userMsg = 'Conexión rechazada por el servidor. El puerto podría estar cerrado o el servicio detenido.';
    } else if (errMsg.includes('certificate') || errMsg.includes('SSL')) {
      userMsg = 'Error de certificado SSL del servidor.';
    } else if (errMsg) {
      userMsg = errMsg;
    }

    return {
      success: false,
      works: false,
      statusCode: lastStatusCode || 0,
      latencyMs,
      message: `LA URL NO FUNCIONA: ${userMsg}`,
      errorDetail: errMsg,
      channels: [],
      vod: [],
      stats: {
        totalChannels: 0,
        totalVod: 0,
        categories: [],
      },
      sourceUrl: rawUrl,
    };
  }
}

/**
 * Parses raw M3U text format
 */
function parseM3uText(text: string, baseServer = '') {
  const lines = text.split('\n');
  const channels: ChannelItem[] = [];
  const vod: VodItem[] = [];
  const categoriesSet = new Set<string>();

  let currentExtinf: {
    name: string;
    logo: string;
    group: string;
    tvgId: string;
  } | null = null;

  let chNumber = 1;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    if (line.startsWith('#EXTINF:')) {
      // Parse tvg-logo, group-title, tvg-name, tvg-id
      const logoMatch = line.match(/tvg-logo="([^"]*)"/i);
      const groupMatch = line.match(/group-title="([^"]*)"/i);
      const tvgIdMatch = line.match(/tvg-id="([^"]*)"/i);

      // Name is everything after last comma
      const commaIdx = line.lastIndexOf(',');
      const rawName = commaIdx !== -1 ? line.substring(commaIdx + 1).trim() : `Canal ${chNumber}`;

      currentExtinf = {
        name: rawName,
        logo:
          logoMatch && logoMatch[1]
            ? logoMatch[1]
            : 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=120&auto=format&fit=crop&q=80',
        group: groupMatch && groupMatch[1] ? groupMatch[1] : 'General',
        tvgId: tvgIdMatch && tvgIdMatch[1] ? tvgIdMatch[1] : '',
      };
    } else if (!line.startsWith('#') && currentExtinf) {
      let streamUrl = line;
      if (!streamUrl.startsWith('http://') && !streamUrl.startsWith('https://') && baseServer) {
        streamUrl = `${baseServer}/${streamUrl.replace(/^\/+/, '')}`;
      }

      const isVod =
        currentExtinf.group.toLowerCase().includes('vod') ||
        currentExtinf.group.toLowerCase().includes('cine') ||
        currentExtinf.group.toLowerCase().includes('pelicula') ||
        currentExtinf.group.toLowerCase().includes('series') ||
        streamUrl.endsWith('.mp4') ||
        streamUrl.endsWith('.mkv');

      categoriesSet.add(currentExtinf.group);

      if (isVod) {
        const yearMatch = currentExtinf.name.match(/\b(19\d\d|20\d\d)\b/);
        const extractedYear = yearMatch ? parseInt(yearMatch[1], 10) : 2026;

        vod.push({
          id: `m3u_vod_${vod.length + 1}`,
          title: currentExtinf.name,
          category: currentExtinf.group,
          type: currentExtinf.group.toLowerCase().includes('series') ? 'series' : 'movie',
          year: extractedYear,
          rating: '8.0',
          poster: currentExtinf.logo,
          synopsis: `Película/Serie de la lista Xtream: ${currentExtinf.name}`,
          duration: '1h 50m',
          url: streamUrl,
          isBlocked: false,
        });
      } else {
        channels.push({
          id: `m3u_ch_${channels.length + 1}`,
          number: chNumber++,
          name: currentExtinf.name,
          category: currentExtinf.group,
          logo: currentExtinf.logo,
          url: streamUrl,
          resolution: '1080p HD',
          isBlocked: false,
          epgNow: {
            title: currentExtinf.name,
            startTime: '00:00',
            endTime: '23:59',
            description: `Señal en vivo de ${currentExtinf.group}`,
          },
          epgNext: {
            title: 'Continuación programación',
            startTime: '23:59',
            endTime: '06:00',
            description: 'Transmisión 24 horas continuas.',
          },
        });
      }

      currentExtinf = null;
    }
  }

  return {
    channels,
    vod: vod.sort((a, b) => (Number(b.year) || 0) - (Number(a.year) || 0)),
    categories: Array.from(categoriesSet),
  };
}
