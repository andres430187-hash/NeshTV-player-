import Hls from 'hls.js';
import mpegts from 'mpegts.js';

export type PlayerEngineType = 'hls' | 'mpegts' | 'native' | 'proxy-hls' | 'proxy-ts' | 'exoplayer';
export type PlayerStatusType = 'connecting' | 'playing' | 'buffering' | 'error';

export interface StreamQualityLevel {
  index: number;
  height: number;
  width?: number;
  bitrate: number;
  name: string;
}

export interface PlaybackSession {
  destroy: () => void;
  retryWithProxy: () => void;
  retryWithEngine: (engine: PlayerEngineType) => void;
  getLevels: () => StreamQualityLevel[];
  getCurrentLevel: () => number; // -1 for Auto, or 0, 1, 2...
  setLevel: (levelIndex: number) => void;
}

export interface PlaybackConfig {
  url: string;
  video: HTMLVideoElement;
  bufferSize?: number;
  forceProxy?: boolean;
  onStatusChange?: (status: PlayerStatusType, detail?: string) => void;
  onEngineChange?: (engine: PlayerEngineType) => void;
  onLevelsLoaded?: (levels: StreamQualityLevel[]) => void;
  onLevelChange?: (levelIndex: number, levelName: string) => void;
}

/**
 * Universal IPTV Stream Player with Adaptive Bitrate (ABR)
 * Automatically handles:
 * - Seamless background failover without blocking error screens
 * - Adaptive Bitrate: auto-downshifts on slow internet, auto-upshifts when bandwidth recovers
 * - User Quality Selection (Auto, 1080p, 720p, 480p, 360p)
 * - HTTPS Mixed Content bypass and CORS proxy routing
 * - HLS (.m3u8) & MPEG-TS (.ts) playback engines
 */
export function playUniversalStream(config: PlaybackConfig): PlaybackSession {
  const {
    url: rawUrl,
    video,
    bufferSize = 25,
    forceProxy = false,
    onStatusChange,
    onEngineChange,
    onLevelsLoaded,
    onLevelChange,
  } = config;

  let isDestroyed = false;
  let activeHls: Hls | null = null;
  let activeMpegts: mpegts.Player | null = null;
  let hasReceivedPlaying = false;
  let fallbackTimer: NodeJS.Timeout | null = null;
  let autoRecoverTimer: NodeJS.Timeout | null = null;
  let silentReconnectTimer: NodeJS.Timeout | null = null;
  let currentQualityLevels: StreamQualityLevel[] = [];
  let userPreferredLevel = -1; // -1 = Auto

  const cleanUrl = (rawUrl || '').trim();
  if (!cleanUrl) {
    onStatusChange?.('error', 'URL de transmisión vacía');
    return {
      destroy: () => {},
      retryWithProxy: () => {},
      retryWithEngine: () => {},
      getLevels: () => [],
      getCurrentLevel: () => -1,
      setLevel: () => {},
    };
  }

  // Detect environment
  const isHttps = typeof window !== 'undefined' && window.location.protocol === 'https:';
  const isHttpStream = cleanUrl.startsWith('http://');
  const needsProxy = forceProxy || (isHttps && isHttpStream);

  const getProxyUrl = (targetUrl: string) => `/api/proxy/stream?url=${encodeURIComponent(targetUrl)}`;

  const isExplicitHls = cleanUrl.includes('.m3u8') || cleanUrl.includes('m3u') || cleanUrl.includes('output=hls');
  const isTsStream = cleanUrl.includes('.ts') || cleanUrl.includes('/live/');

  // Cleanup helper
  const cleanup = () => {
    if (fallbackTimer) {
      clearTimeout(fallbackTimer);
      fallbackTimer = null;
    }
    if (autoRecoverTimer) {
      clearTimeout(autoRecoverTimer);
      autoRecoverTimer = null;
    }
    if (silentReconnectTimer) {
      clearTimeout(silentReconnectTimer);
      silentReconnectTimer = null;
    }
    if (activeHls) {
      try {
        activeHls.destroy();
      } catch {}
      activeHls = null;
    }
    if (activeMpegts) {
      try {
        activeMpegts.pause();
        activeMpegts.unload();
        activeMpegts.detachMediaElement();
        activeMpegts.destroy();
      } catch {}
      activeMpegts = null;
    }
    try {
      video.removeAttribute('src');
      video.load();
    } catch {}
  };

  // Wire HTML5 video events
  const onPlaying = () => {
    if (isDestroyed) return;
    hasReceivedPlaying = true;
    if (fallbackTimer) clearTimeout(fallbackTimer);
    onStatusChange?.('playing');
  };

  // Adaptive Bitrate Watchdog:
  // When slow connection causes buffering or stalling, automatically step down
  // quality to lowest bitrate so stream NEVER freezes!
  const onWaiting = () => {
    if (isDestroyed) return;
    onStatusChange?.('buffering', 'Cargando...');

    if (activeHls && (userPreferredLevel === -1 || activeHls.autoLevelEnabled)) {
      if (currentQualityLevels.length > 1) {
        // Temporarily clamp to lowest bitrate (index 0) to unfreeze immediately!
        activeHls.nextAutoLevel = 0;
        if (autoRecoverTimer) clearTimeout(autoRecoverTimer);
        autoRecoverTimer = setTimeout(() => {
          if (!isDestroyed && activeHls && userPreferredLevel === -1) {
            activeHls.nextAutoLevel = -1; // smoothly restore Auto
          }
        }, 12000);
      }
    }
  };

  const onStalled = () => {
    if (isDestroyed) return;
    if (!hasReceivedPlaying) {
      onStatusChange?.('buffering', 'Cargando...');
    } else if (activeHls && userPreferredLevel === -1) {
      activeHls.nextAutoLevel = 0;
    }
  };

  video.addEventListener('playing', onPlaying);
  video.addEventListener('waiting', onWaiting);
  video.addEventListener('stalled', onStalled);

  // Strategy 1: HLS via hls.js with Adaptive Bitrate (ABR)
  const tryHls = (playbackUrl: string, isProxied: boolean, onFailRaw: () => void) => {
    let failed = false;
    const onFail = () => { if (failed) return; failed = true; onFailRaw(); };
    if (isDestroyed) return;
    cleanup();

    if (!Hls.isSupported()) {
      onFail();
      return;
    }

    onEngineChange?.(isProxied ? 'proxy-hls' : 'hls');
    onStatusChange?.('connecting', 'Cargando...');

    const hls = new Hls({
      maxBufferLength: 30,
      maxMaxBufferLength: 60,
      enableWorker: true,
      lowLatencyMode: false,
      backBufferLength: 15,
      manifestLoadingTimeOut: 15000,
      manifestLoadingMaxRetry: 4,
      levelLoadingTimeOut: 15000,
      fragLoadingTimeOut: 20000,
      capLevelToPlayerSize: true,
      abrEwmaDefaultEstimate: 900000, // Balanced initial estimate (900kbps) to avoid starting at too high quality
      abrMaxWithRealBitrate: true,
      maxLoadingDelay: 4,
      minAutoBitrate: 200000,
    });
    activeHls = hls;
    hls.autoLevelCapping = -1;

    hls.attachMedia(video);

    hls.on(Hls.Events.MEDIA_ATTACHED, () => {
      if (isDestroyed) return;
      hls.loadSource(playbackUrl);
    });

    hls.on(Hls.Events.MANIFEST_PARSED, (_event, data) => {
      if (isDestroyed) return;
      if (data && Array.isArray(data.levels) && data.levels.length > 0) {
        currentQualityLevels = data.levels.map((lvl, idx) => ({
          index: idx,
          height: lvl.height || 0,
          width: lvl.width || 0,
          bitrate: lvl.bitrate || 0,
          name: lvl.height
            ? `${lvl.height}p`
            : `Opción ${idx + 1} (${Math.round((lvl.bitrate || 0) / 1000)}k)`,
        }));
        onLevelsLoaded?.(currentQualityLevels);

        // Apply user preference if manual
        if (userPreferredLevel >= 0 && userPreferredLevel < data.levels.length) {
          hls.currentLevel = userPreferredLevel;
        }
      }
      video.play().catch(() => onStatusChange?.('buffering', 'Iniciando reproducción...'));
    });

    hls.on(Hls.Events.LEVEL_SWITCHED, (_event, data) => {
      if (isDestroyed) return;
      const lvl = currentQualityLevels.find((l) => l.index === data.level);
      const name = lvl ? lvl.name : `Nivel ${data.level}`;
      onLevelChange?.(data.level, name);
    });

    hls.on(Hls.Events.ERROR, (_evt, data) => {
      if (isDestroyed) return;
      if (data.fatal) {
        switch (data.type) {
          case Hls.ErrorTypes.NETWORK_ERROR:
            if (!hasReceivedPlaying) {
              onFail();
            } else {
              hls.startLoad();
            }
            break;
          case Hls.ErrorTypes.MEDIA_ERROR:
            hls.recoverMediaError();
            break;
          default:
            onFail();
            break;
        }
      }
    });

    // Balanced connection timeout (9000ms) to give adequate time for stream handshake without premature switching
    fallbackTimer = setTimeout(() => {
      if (!hasReceivedPlaying && !isDestroyed) {
        onFail();
      }
    }, 9000);
  };

  // Strategy 2: MPEG-TS via mpegts.js
  const tryMpegts = (playbackUrl: string, isProxied: boolean, onFailRaw: () => void) => {
    let failed = false;
    const onFail = () => { if (failed) return; failed = true; onFailRaw(); };
    if (isDestroyed) return;
    cleanup();

    if (!mpegts.isSupported()) {
      onFail();
      return;
    }

    onEngineChange?.(isProxied ? 'proxy-ts' : 'mpegts');
    onStatusChange?.('connecting', isProxied ? 'Conectando túnel seguro...' : 'Conectando MPEG-TS...');

    try {
      const player = mpegts.createPlayer(
        {
          type: 'm2ts',
          isLive: true,
          url: playbackUrl,
          cors: true,
        },
        {
          enableWorker: true,
          lazyLoad: false,
          stashInitialSize: 128,
          enableStashBuffer: false,
          liveBufferLatencyChasing: true,
          liveBufferLatencyMaxLatency: 3.0,
          liveBufferLatencyMinRemain: 0.8,
        }
      );
      activeMpegts = player;

      player.attachMediaElement(video);
      player.load();
      try {
        const playPromise = player.play();
        if (playPromise && typeof (playPromise as any).catch === 'function') {
          (playPromise as any).catch(() => {});
        }
      } catch {}

      player.on(mpegts.Events.ERROR, () => {
        if (isDestroyed) return;
        if (!hasReceivedPlaying) {
          onFail();
        }
      });

      fallbackTimer = setTimeout(() => {
        if (!hasReceivedPlaying && !isDestroyed) {
          onFail();
        }
      }, 9000);
    } catch {
      onFail();
    }
  };

  // Strategy 3: Native HTML5 Video Element
  const tryNative = (playbackUrl: string, onFailRaw: () => void) => {
    let failed = false;
    const onFail = () => { if (failed) return; failed = true; onFailRaw(); };
    if (isDestroyed) return;
    cleanup();

    onEngineChange?.('native');
    onStatusChange?.('connecting', 'Conectando reproductor...');

    video.src = playbackUrl;
    video.load();
    try {
      const playPromise = video.play();
      if (playPromise && typeof playPromise.catch === 'function') {
        playPromise.catch(() => {});
      }
    } catch {}

    video.onerror = () => {
      if (isDestroyed) return;
      onFail();
    };

    fallbackTimer = setTimeout(() => {
      if (!hasReceivedPlaying && !isDestroyed) {
        onFail();
      }
    }, 9000);
  };

  // Main Orchestration Execution Flow
  const startPlayback = () => {
    hasReceivedPlaying = false;

    const targetUrl = needsProxy ? getProxyUrl(cleanUrl) : cleanUrl;

    // Check if running inside Android container with native AndroidX Media3 ExoPlayer bridge
    if (typeof window !== 'undefined' && (window as any).AndroidExoPlayer && typeof (window as any).AndroidExoPlayer.playStream === 'function') {
      onEngineChange?.('exoplayer');
      onStatusChange?.('connecting', 'Iniciando AndroidX Media3 ExoPlayer...');
      try {
        (window as any).AndroidExoPlayer.playStream(targetUrl);
        hasReceivedPlaying = true;
        onStatusChange?.('playing');
        return;
      } catch {
        // Fall back to web engines if native bridge throws error
      }
    }

    const handleAllExhausted = () => {
      if (isDestroyed) return;
      onStatusChange?.('error', 'No se pudo conectar con el canal. Comprueba tu conexión o servidor.');
    };

    const isHlsPreferred = cleanUrl.includes('.m3u8') || cleanUrl.includes('m3u') || cleanUrl.includes('output=hls');

    const proxyUrl = getProxyUrl(cleanUrl);
    // Most IPTV/Xtream servers don't send CORS headers, so a direct attempt
    // usually fails in the browser. Always fall back to the server proxy.
    const proxyChain = () => {
      if (isHlsPreferred) {
        tryHls(proxyUrl, true, () => tryMpegts(proxyUrl, true, () => tryNative(proxyUrl, handleAllExhausted)));
      } else {
        tryMpegts(proxyUrl, true, () => tryHls(proxyUrl, true, () => tryNative(proxyUrl, handleAllExhausted)));
      }
    };

    if (needsProxy) {
      proxyChain();
    } else if (isHlsPreferred) {
      tryHls(targetUrl, false, proxyChain);
    } else {
      tryMpegts(targetUrl, false, proxyChain);
    }
  };

  startPlayback();

  return {
    destroy: () => {
      isDestroyed = true;
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('stalled', onStalled);
      cleanup();
    },
    retryWithProxy: () => {
      cleanup();
      hasReceivedPlaying = false;
      const hlsUrl = cleanUrl.replace(/\.ts(\?.*)?$/i, '.m3u8$1');
      tryHls(getProxyUrl(hlsUrl), true, () => {
        tryMpegts(getProxyUrl(cleanUrl), true, () => {
          onStatusChange?.('buffering', 'Reconectando con túnel proxy...');
        });
      });
    },
    retryWithEngine: (engine: PlayerEngineType) => {
      cleanup();
      hasReceivedPlaying = false;
      if (engine === 'hls') {
        tryHls(cleanUrl, false, () => {});
      } else if (engine === 'proxy-hls') {
        tryHls(getProxyUrl(cleanUrl), true, () => {});
      } else if (engine === 'mpegts') {
        tryMpegts(cleanUrl, false, () => {});
      } else if (engine === 'proxy-ts') {
        tryMpegts(getProxyUrl(cleanUrl), true, () => {});
      } else {
        tryNative(cleanUrl, () => {});
      }
    },
    getLevels: () => currentQualityLevels,
    getCurrentLevel: () => (activeHls ? activeHls.currentLevel : -1),
    setLevel: (levelIndex: number) => {
      userPreferredLevel = levelIndex;
      if (activeHls) {
        activeHls.currentLevel = levelIndex;
      }
    },
  };
}
