import React, { useState, useEffect } from 'react';
import { NeshLogo } from './NeshLogo.tsx';
import { UserAccount, ChannelItem, VodItem, FloatingMessage } from '../types/index.ts';
import {
  Tv,
  Film,
  Clapperboard,
  Settings,
  LogOut,
  Calendar,
  Clock,
  Bell,
  Radio,
  FileCode2,
  Shield,
  Smartphone,
  Sparkles,
} from 'lucide-react';

interface DashboardProps {
  user: UserAccount;
  channels: ChannelItem[];
  vod: VodItem[];
  floatingMessage: FloatingMessage | null;
  onNavigate: (view: 'livetv' | 'movies' | 'series' | 'settings' | 'admin') => void;
  onLogout: () => void;
  onToggleRemote: () => void;
  deviceMode: 'tv' | 'mobile';
  setDeviceMode: (mode: 'tv' | 'mobile') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  user,
  channels,
  vod,
  floatingMessage,
  onNavigate,
  onLogout,
  onToggleRemote,
  deviceMode,
  setDeviceMode,
}) => {
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');

  // Live Clock updater
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('es-ES', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        })
      );
      setCurrentDate(
        now.toLocaleDateString('es-ES', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        })
      );
    };

    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const movieCount = vod.filter((v) => v.type === 'movie').length;
  const seriesCount = vod.filter((v) => v.type === 'series').length;

  return (
    <div className="relative min-h-screen w-full bg-[#000000] text-white flex flex-col justify-between overflow-x-hidden p-4 md:p-8 select-none">
      {/* Background ambient lighting */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-1/4 w-[600px] h-[300px] bg-[#00F0FF]/5 rounded-full blur-[140px]" />
        <div className="absolute bottom-10 right-1/4 w-[500px] h-[350px] bg-[#00F0FF]/5 rounded-full blur-[140px]" />
      </div>

      {/* Top Header: Logo, Time/Date, User status & Quick Actions */}
      <header className="w-full z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div className="flex items-center gap-6">
          <NeshLogo size="lg" showSubtitle />

          {/* Device mode toggle badge */}
          <div className="hidden sm:flex items-center bg-zinc-900/90 border border-zinc-800 rounded-lg p-1 text-xs">
            <button
              onClick={() => setDeviceMode('tv')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors ${
                deviceMode === 'tv'
                  ? 'bg-[#00F0FF]/20 text-[#00F0FF] font-semibold border border-[#00F0FF]/50'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Tv className="w-3.5 h-3.5" />
              <span>Smart TV D-Pad</span>
            </button>
            <button
              onClick={() => setDeviceMode('mobile')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors ${
                deviceMode === 'mobile'
                  ? 'bg-[#00F0FF]/20 text-[#00F0FF] font-semibold border border-[#00F0FF]/50'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Móvil Touch</span>
            </button>
          </div>
        </div>

        {/* Center: Live Clock and Date */}
        <div className="flex flex-col items-start md:items-center text-left md:text-center">
          <div className="flex items-center gap-2 text-2xl md:text-3xl font-extrabold tracking-wider font-mono text-white">
            <Clock className="w-5 h-5 text-[#00F0FF]" />
            <span className="drop-shadow-[0_0_10px_rgba(0,240,255,0.4)]">{currentTime || '00:00:00'}</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-zinc-400 capitalize mt-0.5">
            <Calendar className="w-3.5 h-3.5 text-zinc-500" />
            <span>{currentDate}</span>
          </div>
        </div>

        {/* Right side: User expiration info & Action buttons */}
        <div className="flex items-center flex-wrap gap-2.5">
          {/* User Account Expiry Pill */}
          <div className="bg-[#121212] border border-zinc-800 rounded-xl px-3 py-1.5 flex items-center gap-2.5">
            <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
            <div className="text-left">
              <div className="text-xs font-bold text-white flex items-center gap-1">
                <span>{user.username}</span>
              </div>
              <div className="text-[10px] text-zinc-400">
                Vence: <span className="text-[#00F0FF] font-semibold">{user.expiryDate}</span>
              </div>
            </div>
          </div>

          {/* Quick Settings */}
          <button
            onClick={() => onNavigate('settings')}
            data-tv-focus="true"
            data-focus-id="btn-nav-settings"
            className="tv-focusable p-2 rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-[#00F0FF] text-zinc-300 hover:text-[#00F0FF] transition-all"
            title="Ajustes del Reproductor"
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* Admin Panel button - Strictly visible ONLY for the owner */}
          {user.username === 'admin' && (
            <button
              onClick={() => onNavigate('admin')}
              data-tv-focus="true"
              data-focus-id="btn-nav-admin"
              className="tv-focusable p-2 rounded-xl bg-zinc-900/90 border border-[#00F0FF]/40 hover:border-[#00F0FF] text-[#00F0FF] transition-all"
              title="Panel de Administración"
            >
              <Shield className="w-5 h-5" />
            </button>
          )}

          {/* Remote Toggle */}
          <button
            onClick={onToggleRemote}
            data-tv-focus="true"
            data-focus-id="btn-nav-remote"
            className="tv-focusable p-2 rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-[#00F0FF] text-zinc-300 hover:text-[#00F0FF] transition-all"
            title="Control Remoto Virtual"
          >
            <Tv className="w-5 h-5" />
          </button>

          {/* Logout */}
          <button
            onClick={onLogout}
            data-tv-focus="true"
            data-focus-id="btn-nav-logout"
            className="tv-focusable p-2 rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-red-500 text-zinc-400 hover:text-red-400 transition-all"
            title="Cerrar Sesión"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Floating Notice / Announcement Bar (Requirement 4: Espacio visual en una esquina para mostrar el mensaje flotante) */}
      {floatingMessage && floatingMessage.active && (
        <aside
          role="complementary"
          aria-label="Aviso del sistema"
          className="z-20 my-3 w-full bg-gradient-to-r from-[#00F0FF]/15 via-zinc-900 to-black/80 border border-[#00F0FF]/40 rounded-xl p-3 shadow-[0_0_20px_rgba(0,240,255,0.15)] flex items-center justify-between gap-3 animate-fade-in"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#00F0FF]/20 text-[#00F0FF] shrink-0 shadow-[0_0_10px_rgba(0,240,255,0.4)]">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wider text-[#00F0FF]">
                {floatingMessage.sender || 'Notificación del Administrador'}
              </div>
              <div className="text-xs md:text-sm text-zinc-200 font-medium">
                {floatingMessage.text}
              </div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-1.5 text-[11px] text-[#00F0FF] font-semibold bg-black/40 px-2.5 py-1 rounded-md border border-[#00F0FF]/20">
            <Radio className="w-3 h-3 animate-pulse text-[#00F0FF]" />
            <span>En vivo</span>
          </div>
        </aside>
      )}

      {/* Main 3 IPTV Smarters Big Interactive Cards (Requirement 4) */}
      <main className="z-10 my-auto py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-7">
          {/* Card 1: LIVE TV (TV en Vivo) */}
          <div
            onClick={() => onNavigate('livetv')}
            data-tv-focus="true"
            data-focus-id="card-live-tv"
            tabIndex={0}
            className="tv-focusable group relative h-64 md:h-80 rounded-2xl overflow-hidden cursor-pointer border border-zinc-800 bg-[#121212] hover:border-[#00F0FF] shadow-[0_15px_35px_rgba(0,0,0,0.8)] transition-all duration-300"
          >
            {/* Background Image */}
            <img
              src="/src/assets/images/neshtv_live_tv_1792501774775.jpg"
              alt="TV en Vivo"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-60 group-hover:opacity-75"
            />
            {/* Scrim Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

            {/* Glowing Accent Badge */}
            <div className="absolute top-4 left-4 flex items-center gap-2 bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-lg border border-red-500/40 text-xs font-bold text-red-400">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span>LIVE</span>
            </div>

            <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-lg border border-zinc-700 text-xs text-zinc-300">
              <span className="text-[#00F0FF] font-bold">{channels.length}</span> Canales
            </div>

            {/* Card Content */}
            <div className="absolute bottom-6 left-6 right-6">
              <div className="p-3 w-12 h-12 rounded-xl bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/40 mb-3 flex items-center justify-center group-hover:scale-110 shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-transform">
                <Tv className="w-6 h-6" />
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight group-hover:text-[#00F0FF] transition-colors">
                Live TV
              </h2>
              <p className="text-xs md:text-sm text-zinc-300 mt-1 line-clamp-1">
                Televisión en directo, deportes y guía interactiva EPG
              </p>

              {/* Action hint */}
              <div className="mt-3 flex items-center text-xs font-bold text-[#00F0FF] gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <span>PRESIONA PARA ENTRAR</span>
                <span>→</span>
              </div>
            </div>
          </div>

          {/* Card 2: MOVIES (Películas) */}
          <div
            onClick={() => onNavigate('movies')}
            data-tv-focus="true"
            data-focus-id="card-movies"
            tabIndex={0}
            className="tv-focusable group relative h-64 md:h-80 rounded-2xl overflow-hidden cursor-pointer border border-zinc-800 bg-[#121212] hover:border-[#00F0FF] shadow-[0_15px_35px_rgba(0,0,0,0.8)] transition-all duration-300"
          >
            <img
              src="/src/assets/images/neshtv_movies_1792501775526.jpg"
              alt="Películas"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-60 group-hover:opacity-75"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

            <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#00F0FF]/40 text-xs font-bold text-[#00F0FF]">
              <span>VOD</span>
            </div>

            <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-lg border border-zinc-700 text-xs text-zinc-300">
              <span className="text-[#00F0FF] font-bold">{movieCount}</span> Títulos
            </div>

            <div className="absolute bottom-6 left-6 right-6">
              <div className="p-3 w-12 h-12 rounded-xl bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/40 mb-3 flex items-center justify-center group-hover:scale-110 shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-transform">
                <Film className="w-6 h-6" />
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight group-hover:text-[#00F0FF] transition-colors">
                Movies
              </h2>
              <p className="text-xs md:text-sm text-zinc-300 mt-1 line-clamp-1">
                Estrenos de cine, taquilla internacional y clásicos en 4K
              </p>

              <div className="mt-3 flex items-center text-xs font-bold text-[#00F0FF] gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <span>VER CATÁLOGO</span>
                <span>→</span>
              </div>
            </div>
          </div>

          {/* Card 3: SERIES (Series) */}
          <div
            onClick={() => onNavigate('series')}
            data-tv-focus="true"
            data-focus-id="card-series"
            tabIndex={0}
            className="tv-focusable group relative h-64 md:h-80 rounded-2xl overflow-hidden cursor-pointer border border-zinc-800 bg-[#121212] hover:border-[#00F0FF] shadow-[0_15px_35px_rgba(0,0,0,0.8)] transition-all duration-300"
          >
            <img
              src="/src/assets/images/neshtv_series_1792501775619.jpg"
              alt="Series de TV"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-60 group-hover:opacity-75"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

            <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-lg border border-purple-500/40 text-xs font-bold text-purple-400">
              <span>SERIES</span>
            </div>

            <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-lg border border-zinc-700 text-xs text-zinc-300">
              <span className="text-[#00F0FF] font-bold">{seriesCount}</span> Series
            </div>

            <div className="absolute bottom-6 left-6 right-6">
              <div className="p-3 w-12 h-12 rounded-xl bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/40 mb-3 flex items-center justify-center group-hover:scale-110 shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-transform">
                <Clapperboard className="w-6 h-6" />
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight group-hover:text-[#00F0FF] transition-colors">
                Series
              </h2>
              <p className="text-xs md:text-sm text-zinc-300 mt-1 line-clamp-1">
                Temporadas completas, episodios bajo demanda y maratones
              </p>

              <div className="mt-3 flex items-center text-xs font-bold text-[#00F0FF] gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <span>EXPLORAR SERIES</span>
                <span>→</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer Navigation Strip & Shortcuts */}
      <footer className="w-full z-10 flex flex-col md:flex-row items-center justify-between gap-3 pt-4 border-t border-zinc-800/80 text-xs text-zinc-400">
        <div className="flex items-center gap-4 flex-wrap">
          <button
            onClick={() => onNavigate('settings')}
            className="hover:text-[#00F0FF] transition-colors flex items-center gap-1.5"
          >
            <Settings className="w-3.5 h-3.5 text-[#00F0FF]" />
            <span>Configuración del Reproductor</span>
          </button>
          {user.username === 'admin' && (
            <>
              <span>·</span>
              <button
                onClick={() => onNavigate('admin')}
                className="hover:text-[#00F0FF] transition-colors flex items-center gap-1.5 text-[#00F0FF]"
              >
                <Shield className="w-3.5 h-3.5 text-[#00F0FF]" />
                <span>Panel de Administración</span>
              </button>
            </>
          )}
        </div>

        <div className="flex items-center gap-3">
          <span className="text-zinc-500">NeshTV v3.0 Pro IPTV</span>
          <span className="text-zinc-600">|</span>
          <span className="text-zinc-400 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#00F0FF]" /> D-Pad & Touch Habilitado
          </span>
        </div>
      </footer>
    </div>
  );
};
