import React, { useState, useEffect, useCallback } from 'react';
import {
  RemoteNavigationProvider,
  useRemoteNavigation,
} from './context/RemoteNavigationContext.tsx';
import { LoginScreen } from './components/LoginScreen.tsx';
import { Dashboard } from './components/Dashboard.tsx';
import { LiveTvPlayer } from './components/LiveTvPlayer.tsx';
import { VodBrowser } from './components/VodBrowser.tsx';
import { PlayerSettingsModal } from './components/PlayerSettingsModal.tsx';
import { AdminPanel } from './components/AdminPanel.tsx';
import { VirtualRemote } from './components/VirtualRemote.tsx';
import {
  UserAccount,
  ChannelItem,
  VodItem,
  FloatingMessage,
  PlayerSettings,
  AppView,
} from './types/index.ts';

const DEFAULT_SETTINGS: PlayerSettings = {
  decoder: 'hardware',
  bufferSize: 20,
  enableOpenSLES: true,
  enableOpenGL: true,
  playbackFormat: 'hls',
  categoryEngines: {
    live: 'ExoPlayer Built-in (Recomendado)',
    movies: 'VLC Hardware Engine',
    series: 'VLC Hardware Engine',
    catchup: 'IjkPlayer Fast-Seek',
    recording: 'Standard MediaCodec',
    liveWithGuide: 'ExoPlayer Low-Latency',
  },
};

function NeshTvApp() {
  const [currentView, setCurrentView] = useState<AppView>('login');
  const [user, setUser] = useState<UserAccount | null>(null);
  const [channels, setChannels] = useState<ChannelItem[]>([]);
  const [vod, setVod] = useState<VodItem[]>([]);
  const [contactNote, setContactNote] = useState<string>('');
  const [floatingMessage, setFloatingMessage] = useState<FloatingMessage | null>(null);
  const [playerSettings, setPlayerSettings] = useState<PlayerSettings>(DEFAULT_SETTINGS);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [adminToken, setAdminToken] = useState<string | null>(null);

  const { deviceMode, setDeviceMode, setShowVirtualRemote, setActiveScreen } = useRemoteNavigation();

  // Load public contact note on app launch
  const fetchPublicInfo = useCallback(async () => {
    try {
      const res = await fetch('/api/public/info');
      if (res.ok) {
        const data = await res.json();
        if (data.contactNote) {
          setContactNote(data.contactNote);
        }
      }
    } catch (e) {
      console.warn('Could not load public info:', e);
    }
  }, []);

  useEffect(() => {
    fetchPublicInfo();
  }, [fetchPublicInfo]);

  useEffect(() => {
    setActiveScreen(currentView);
  }, [currentView, setActiveScreen]);

  // Handle Remote Back key events
  useEffect(() => {
    const handleRemoteBack = () => {
      if (isAdminOpen) {
        setIsAdminOpen(false);
        return;
      }
      if (isSettingsOpen) {
        setIsSettingsOpen(false);
        return;
      }
      if (currentView === 'livetv' || currentView === 'movies' || currentView === 'series') {
        setCurrentView('dashboard');
      }
    };

    const handleRemoteHome = () => {
      if (user) {
        setIsAdminOpen(false);
        setIsSettingsOpen(false);
        setCurrentView('dashboard');
      }
    };

    window.addEventListener('nesh:back', handleRemoteBack);
    window.addEventListener('nesh:home', handleRemoteHome);
    return () => {
      window.removeEventListener('nesh:back', handleRemoteBack);
      window.removeEventListener('nesh:home', handleRemoteHome);
    };
  }, [isAdminOpen, isSettingsOpen, currentView, user]);

  const handleLoginSuccess = (data: {
    user: UserAccount;
    channels: ChannelItem[];
    vod: VodItem[];
    contactNote: string;
    floatingMessage: FloatingMessage | null;
    playerSettings: PlayerSettings;
    isAdmin?: boolean;
    adminToken?: string | null;
  }) => {
    setUser(data.user);
    setChannels(data.channels || []);
    setVod(data.vod || []);
    setContactNote(data.contactNote || '');
    setFloatingMessage(data.floatingMessage || null);
    if (data.adminToken) setAdminToken(data.adminToken);
    if (data.playerSettings) setPlayerSettings(data.playerSettings);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setAdminToken(null);
    setCurrentView('login');
    fetchPublicInfo();
  };

  const handleSaveSettings = async (newSettings: PlayerSettings) => {
    setPlayerSettings(newSettings);
    try {
      await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings),
      });
    } catch (e) {
      console.error('Error saving settings to backend:', e);
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-black text-white antialiased">
      {/* Screen 1: Login */}
      {currentView === 'login' && (
        <LoginScreen
          onLoginSuccess={handleLoginSuccess}
          onOpenAdmin={(token) => {
            if (token) setAdminToken(token);
            setIsAdminOpen(true);
          }}
          contactNote={contactNote}
        />
      )}

      {/* Screen 2: Dashboard (IPTV Smarters style) */}
      {currentView === 'dashboard' && user && (
        <Dashboard
          user={user}
          channels={channels}
          vod={vod}
          floatingMessage={floatingMessage}
          onNavigate={(view) => {
            if (view === 'settings') {
              setIsSettingsOpen(true);
            } else if (view === 'admin') {
              setIsAdminOpen(true);
            } else {
              setCurrentView(view);
            }
          }}
          onLogout={handleLogout}
          onToggleRemote={() => setShowVirtualRemote((prev) => !prev)}
          deviceMode={deviceMode}
          setDeviceMode={setDeviceMode}
        />
      )}

      {/* Screen 3: Live TV Player (Split View & Fullscreen TV) */}
      {currentView === 'livetv' && (
        <LiveTvPlayer
          channels={channels}
          playerSettings={playerSettings}
          onBack={() => setCurrentView('dashboard')}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
      )}

      {/* Screen 4: Movies VOD Browser */}
      {currentView === 'movies' && (
        <VodBrowser
          type="movie"
          items={vod}
          onBack={() => setCurrentView('dashboard')}
        />
      )}

      {/* Screen 5: Series VOD Browser */}
      {currentView === 'series' && (
        <VodBrowser
          type="series"
          items={vod}
          onBack={() => setCurrentView('dashboard')}
        />
      )}

      {/* Built-in Player Technical Configuration Modal (Requirement 6) */}
      <PlayerSettingsModal
        isOpen={isSettingsOpen}
        initialSettings={playerSettings}
        onClose={() => setIsSettingsOpen(false)}
        onSave={handleSaveSettings}
      />

      {/* Private Web Admin Panel (Requirement 3) */}
      {isAdminOpen && (
        <AdminPanel
          initialAdminToken={adminToken || undefined}
          onClose={() => {
            setIsAdminOpen(false);
            fetchPublicInfo();
          }}
        />
      )}

      {/* Virtual Remote Control Simulator for TV Box Leanback testing */}
      <VirtualRemote />
    </div>
  );
}

export default function App() {
  return (
    <RemoteNavigationProvider>
      <NeshTvApp />
    </RemoteNavigationProvider>
  );
}
